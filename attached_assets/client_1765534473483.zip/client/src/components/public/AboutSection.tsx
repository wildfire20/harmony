import { Card, CardContent } from "@/components/ui/card";
import { Heart, BookOpen, Home, Award } from "lucide-react";
import logoImage from "@assets/Harmony_Learning_Logo_Design_1765479534667.png";
import classroomImage from "@assets/WhatsApp_Image_2025-12-11_at_20.20.30_1765479481342.jpeg";
import teacherImage from "@assets/WhatsApp_Image_2025-12-11_at_20.20.57_1765479481343.jpeg";

export function AboutSection() {
  const values = [
    {
      icon: Heart,
      title: "Nurturing Environment",
      description: "Every child receives individual attention and care in our warm, supportive classrooms."
    },
    {
      icon: BookOpen,
      title: "Quality Education",
      description: "Our curriculum balances academic excellence with creative exploration and practical skills."
    },
    {
      icon: Home,
      title: "Boarding Facilities",
      description: "Safe, comfortable boarding options with supervised activities and wholesome meals."
    },
    {
      icon: Award,
      title: "Holistic Development",
      description: "We focus on developing the whole child - intellectually, emotionally, and socially."
    }
  ];

  return (
    <section id="about" className="py-20 md:py-32 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          <div>
            <div className="flex items-center gap-4 mb-6">
              <img 
                src={logoImage} 
                alt="Harmony Learning Institute Logo" 
                className="h-16 w-auto"
                data-testid="img-about-logo"
              />
            </div>
            
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6" data-testid="text-about-title">
              Building Tomorrow's Leaders{" "}
              <span className="text-primary">Today</span>
            </h2>
            
            <p className="text-lg text-muted-foreground mb-8 leading-relaxed" data-testid="text-about-description">
              At Harmony Learning Institute, we believe that every child has unique potential waiting to be unlocked. 
              Our dedicated team of educators creates an environment where curiosity thrives, 
              creativity flourishes, and confidence grows.
            </p>
            
            <p className="text-base text-muted-foreground mb-8 leading-relaxed">
              Founded on the principles of excellence and care, we offer comprehensive education 
              from preschool through primary school, with boarding options for families seeking 
              a complete learning experience for their children.
            </p>

            <div className="grid grid-cols-2 gap-4">
              {values.map((value, index) => (
                <Card key={index} className="border-0 bg-accent/50">
                  <CardContent className="p-4">
                    <value.icon className="h-8 w-8 text-primary mb-3" />
                    <h3 className="font-semibold mb-1 text-sm" data-testid={`text-value-title-${index}`}>
                      {value.title}
                    </h3>
                    <p className="text-xs text-muted-foreground">
                      {value.description}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <div className="relative">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <div className="relative overflow-hidden rounded-lg aspect-[4/5]">
                  <img 
                    src={classroomImage} 
                    alt="Students learning in classroom" 
                    className="w-full h-full object-cover"
                    data-testid="img-about-classroom"
                  />
                </div>
                <div className="bg-primary rounded-lg p-6 text-primary-foreground">
                  <div className="text-3xl font-bold mb-1">500+</div>
                  <div className="text-sm opacity-90">Happy Learners</div>
                </div>
              </div>
              <div className="space-y-4 pt-8">
                <div className="bg-accent rounded-lg p-6">
                  <div className="text-3xl font-bold text-primary mb-1">25+</div>
                  <div className="text-sm text-muted-foreground">Dedicated Teachers</div>
                </div>
                <div className="relative overflow-hidden rounded-lg aspect-[4/5]">
                  <img 
                    src={teacherImage} 
                    alt="Teacher helping students" 
                    className="w-full h-full object-cover"
                    data-testid="img-about-teacher"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
