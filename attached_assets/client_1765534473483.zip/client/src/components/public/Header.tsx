import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/theme-toggle";
import { Menu, X } from "lucide-react";
import { useState } from "react";
import logoImage from "@assets/Harmony_Learning_Logo_Design_1765479534667.png";

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-4 h-16">
          <Link href="/" className="flex items-center gap-2">
            <img 
              src={logoImage} 
              alt="Harmony Learning Institute" 
              className="h-10 w-auto"
              data-testid="img-logo"
            />
            <span className="hidden sm:block font-semibold text-lg">
              Harmony Learning
            </span>
          </Link>

          <nav className="hidden md:flex items-center gap-6">
            <a href="#about" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors" data-testid="link-about">
              About
            </a>
            <a href="#gallery" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors" data-testid="link-gallery">
              Gallery
            </a>
            <a href="#programs" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors" data-testid="link-programs">
              Programs
            </a>
            <a href="#enroll" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors" data-testid="link-enroll">
              Enroll
            </a>
          </nav>

          <div className="flex items-center gap-2">
            <ThemeToggle />
            <Button variant="outline" size="sm" className="hidden sm:inline-flex" asChild data-testid="button-portal-login">
              <a href="/login">Portal Login</a>
            </Button>
            <Button size="sm" className="hidden sm:inline-flex" asChild data-testid="button-apply-now">
              <a href="#enroll">Apply Now</a>
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              data-testid="button-mobile-menu"
            >
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t">
            <nav className="flex flex-col gap-2">
              <a 
                href="#about" 
                className="px-4 py-2 text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-muted rounded-md transition-colors"
                onClick={() => setMobileMenuOpen(false)}
              >
                About
              </a>
              <a 
                href="#gallery" 
                className="px-4 py-2 text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-muted rounded-md transition-colors"
                onClick={() => setMobileMenuOpen(false)}
              >
                Gallery
              </a>
              <a 
                href="#programs" 
                className="px-4 py-2 text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-muted rounded-md transition-colors"
                onClick={() => setMobileMenuOpen(false)}
              >
                Programs
              </a>
              <a 
                href="#enroll" 
                className="px-4 py-2 text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-muted rounded-md transition-colors"
                onClick={() => setMobileMenuOpen(false)}
              >
                Enroll
              </a>
              <div className="flex gap-2 px-4 pt-2">
                <Button variant="outline" size="sm" className="flex-1" asChild>
                  <a href="/login">Portal Login</a>
                </Button>
                <Button size="sm" className="flex-1" asChild>
                  <a href="#enroll">Apply Now</a>
                </Button>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
