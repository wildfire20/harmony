import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ChevronRight, GraduationCap, Users, Building } from "lucide-react";
import heroImage from "@assets/WhatsApp_Image_2025-12-11_at_20.02.33_1765479481340.jpeg";

export function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${heroImage})` }}
      />
      <div className="absolute inset-0 hero-overlay" />
      
      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center py-20">
        <Badge 
          variant="secondary" 
          className="mb-6 px-4 py-2 text-sm font-medium bg-white/20 backdrop-blur-md text-white border-white/30"
          data-testid="badge-accepting-applications"
        >
          <span className="mr-2">Now Accepting Applications for 2025</span>
          <ChevronRight className="h-4 w-4" />
        </Badge>

        <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight" data-testid="text-hero-title">
          Welcome to{" "}
          <span className="bg-gradient-to-r from-pink-300 to-rose-300 bg-clip-text text-transparent">
            Harmony Learning
          </span>{" "}
          Institute
        </h1>

        <p className="text-lg sm:text-xl md:text-2xl text-white/90 mb-8 max-w-3xl mx-auto leading-relaxed" data-testid="text-hero-subtitle">
          Nurturing Young Minds from Preschool Through Primary
        </p>

        <p className="text-base sm:text-lg text-white/80 mb-10 max-w-2xl mx-auto" data-testid="text-hero-description">
          Where every child is valued, every moment is a learning opportunity, 
          and every day brings new discoveries. Join our family of learners today.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
          <Button 
            size="lg" 
            className="text-lg px-8 py-6 w-full sm:w-auto"
            asChild
            data-testid="button-hero-enroll"
          >
            <a href="#enroll">
              Enroll Your Child
              <ChevronRight className="ml-2 h-5 w-5" />
            </a>
          </Button>
          <Button 
            size="lg" 
            variant="outline" 
            className="text-lg px-8 py-6 w-full sm:w-auto bg-white/10 backdrop-blur-md border-white/30 text-white hover:bg-white/20"
            asChild
            data-testid="button-hero-tour"
          >
            <a href="#gallery">Take a Virtual Tour</a>
          </Button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-2xl mx-auto">
          <div className="flex items-center justify-center gap-2 bg-white/10 backdrop-blur-md rounded-lg px-4 py-3" data-testid="stat-preschool">
            <GraduationCap className="h-5 w-5 text-pink-300" />
            <span className="text-white/90 font-medium">Preschool</span>
          </div>
          <div className="flex items-center justify-center gap-2 bg-white/10 backdrop-blur-md rounded-lg px-4 py-3" data-testid="stat-primary">
            <Users className="h-5 w-5 text-pink-300" />
            <span className="text-white/90 font-medium">Primary School</span>
          </div>
          <div className="flex items-center justify-center gap-2 bg-white/10 backdrop-blur-md rounded-lg px-4 py-3" data-testid="stat-boarding">
            <Building className="h-5 w-5 text-pink-300" />
            <span className="text-white/90 font-medium">Boarding</span>
          </div>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <a href="#about" className="text-white/60 hover:text-white transition-colors">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
          </svg>
        </a>
      </div>
    </section>
  );
}
