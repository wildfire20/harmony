import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MapPin, Phone, Mail, Clock, Facebook, Instagram, Twitter } from "lucide-react";
import logoImage from "@assets/Harmony_Learning_Logo_Design_1765479534667.png";

export function Footer() {
  return (
    <footer className="bg-foreground text-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-3 mb-4">
              <img 
                src={logoImage} 
                alt="Harmony Learning Institute" 
                className="h-12 w-auto bg-white rounded-md p-1"
                data-testid="img-footer-logo"
              />
            </div>
            <p className="text-background/70 text-sm mb-6">
              Nurturing young minds from preschool through primary. 
              Where every child discovers their potential.
            </p>
            <div className="flex gap-3">
              <Button 
                variant="outline" 
                size="icon" 
                className="bg-transparent border-background/20 text-background hover:bg-background/10"
                data-testid="button-facebook"
              >
                <Facebook className="h-4 w-4" />
              </Button>
              <Button 
                variant="outline" 
                size="icon" 
                className="bg-transparent border-background/20 text-background hover:bg-background/10"
                data-testid="button-instagram"
              >
                <Instagram className="h-4 w-4" />
              </Button>
              <Button 
                variant="outline" 
                size="icon" 
                className="bg-transparent border-background/20 text-background hover:bg-background/10"
                data-testid="button-twitter"
              >
                <Twitter className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div>
            <h4 className="font-semibold text-lg mb-4">Quick Links</h4>
            <ul className="space-y-3">
              <li>
                <a href="#about" className="text-background/70 hover:text-background text-sm transition-colors" data-testid="link-footer-about">
                  About Us
                </a>
              </li>
              <li>
                <a href="#programs" className="text-background/70 hover:text-background text-sm transition-colors" data-testid="link-footer-programs">
                  Our Programs
                </a>
              </li>
              <li>
                <a href="#gallery" className="text-background/70 hover:text-background text-sm transition-colors" data-testid="link-footer-gallery">
                  Photo Gallery
                </a>
              </li>
              <li>
                <a href="#enroll" className="text-background/70 hover:text-background text-sm transition-colors" data-testid="link-footer-enroll">
                  Admissions
                </a>
              </li>
              <li>
                <a href="/login" className="text-background/70 hover:text-background text-sm transition-colors" data-testid="link-footer-portal">
                  Student Portal
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-lg mb-4">Contact Info</h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <MapPin className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <span className="text-background/70 text-sm">
                  123 Education Drive<br />
                  Harmony City, HC 12345
                </span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-primary shrink-0" />
                <span className="text-background/70 text-sm">+27 12 345 6789</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-primary shrink-0" />
                <span className="text-background/70 text-sm">info@harmonylearning.edu</span>
              </li>
              <li className="flex items-start gap-3">
                <Clock className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <span className="text-background/70 text-sm">
                  Mon - Fri: 7:00 AM - 5:00 PM<br />
                  Sat: 8:00 AM - 12:00 PM
                </span>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-lg mb-4">Newsletter</h4>
            <p className="text-background/70 text-sm mb-4">
              Stay updated with our latest news and events.
            </p>
            <div className="flex gap-2">
              <Input 
                type="email" 
                placeholder="Your email" 
                className="bg-background/10 border-background/20 text-background placeholder:text-background/50"
                data-testid="input-newsletter-email"
              />
              <Button data-testid="button-subscribe">
                Subscribe
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="border-t border-background/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-background/60 text-sm" data-testid="text-copyright">
              2025 Harmony Learning Institute. All rights reserved.
            </p>
            <div className="flex gap-6">
              <a href="#" className="text-background/60 hover:text-background text-sm transition-colors">
                Privacy Policy
              </a>
              <a href="#" className="text-background/60 hover:text-background text-sm transition-colors">
                Terms of Service
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
