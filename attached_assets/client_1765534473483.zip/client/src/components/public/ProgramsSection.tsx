import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Baby, GraduationCap, Building2, ChevronRight, Clock, Users, BookOpen } from "lucide-react";

const programs = [
  {
    icon: Baby,
    title: "Preschool",
    ages: "Ages 3-5",
    badge: "Early Years",
    description: "A nurturing introduction to learning through play, creativity, and exploration. Our preschool program builds strong foundations for future academic success.",
    features: ["Play-based learning", "Social skill development", "Early literacy & numeracy", "Creative arts & music"],
    color: "bg-pink-100 dark:bg-pink-900/30",
    iconColor: "text-pink-600 dark:text-pink-400",
  },
  {
    icon: GraduationCap,
    title: "Primary School",
    ages: "Grades 1-6",
    badge: "Core Education",
    description: "Comprehensive academic programs designed to challenge and inspire young minds while building essential skills for lifelong learning.",
    features: ["Core curriculum excellence", "Science & technology", "Languages & arts", "Physical education"],
    color: "bg-rose-100 dark:bg-rose-900/30",
    iconColor: "text-rose-600 dark:text-rose-400",
  },
  {
    icon: Building2,
    title: "Boarding Option",
    ages: "All Grades",
    badge: "Residential",
    description: "A home away from home with supervised activities, nutritious meals, and a supportive community that fosters independence and responsibility.",
    features: ["Safe accommodation", "Supervised study time", "Wholesome meals", "Weekend activities"],
    color: "bg-red-100 dark:bg-red-900/30",
    iconColor: "text-red-600 dark:text-red-400",
  },
];

export function ProgramsSection() {
  return (
    <section id="programs" className="py-20 md:py-32 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <Badge variant="secondary" className="mb-4" data-testid="badge-programs">
            Our Programs
          </Badge>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4" data-testid="text-programs-title">
            Education Tailored to{" "}
            <span className="text-primary">Every Stage</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto" data-testid="text-programs-subtitle">
            From first steps in learning to preparing for secondary school, 
            we offer programs that grow with your child.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {programs.map((program, index) => (
            <Card 
              key={index} 
              className="group relative overflow-visible border-0 shadow-lg hover:shadow-xl transition-shadow"
              data-testid={`card-program-${index}`}
            >
              <div className={`absolute -top-6 left-6 ${program.color} rounded-lg p-4 shadow-lg`}>
                <program.icon className={`h-8 w-8 ${program.iconColor}`} />
              </div>
              
              <CardHeader className="pt-12">
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant="outline" className="text-xs">
                    {program.badge}
                  </Badge>
                  <span className="text-xs text-muted-foreground flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {program.ages}
                  </span>
                </div>
                <CardTitle className="text-xl font-bold">{program.title}</CardTitle>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <p className="text-muted-foreground text-sm leading-relaxed">
                  {program.description}
                </p>
                
                <ul className="space-y-2">
                  {program.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center gap-2 text-sm">
                      <div className="h-1.5 w-1.5 rounded-full bg-primary" />
                      <span className="text-muted-foreground">{feature}</span>
                    </li>
                  ))}
                </ul>

                <Button variant="ghost" className="w-full mt-4 group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                  Learn More
                  <ChevronRight className="ml-2 h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-16 bg-accent/50 rounded-2xl p-8 md:p-12">
          <div className="grid md:grid-cols-3 gap-8 text-center">
            <div data-testid="stat-experience">
              <div className="text-4xl md:text-5xl font-bold text-primary mb-2">10+</div>
              <div className="text-muted-foreground">Years of Excellence</div>
            </div>
            <div data-testid="stat-teachers">
              <div className="text-4xl md:text-5xl font-bold text-primary mb-2">25+</div>
              <div className="text-muted-foreground">Qualified Teachers</div>
            </div>
            <div data-testid="stat-students">
              <div className="text-4xl md:text-5xl font-bold text-primary mb-2">500+</div>
              <div className="text-muted-foreground">Happy Students</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
