import { useState } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { X } from "lucide-react";
import image1 from "@assets/WhatsApp_Image_2025-12-11_at_20.02.33_1765479481340.jpeg";
import image2 from "@assets/WhatsApp_Image_2025-12-11_at_20.19.14_1765479481341.jpeg";
import image3 from "@assets/WhatsApp_Image_2025-12-11_at_20.20.30_1765479481342.jpeg";
import image4 from "@assets/WhatsApp_Image_2025-12-11_at_20.20.57_1765479481343.jpeg";

const galleryImages = [
  { src: image1, alt: "Happy learners enjoying outdoor activities", caption: "Our Happy Learners" },
  { src: image2, alt: "Students during morning assembly", caption: "Morning Assembly" },
  { src: image3, alt: "Students learning in classroom", caption: "Classroom Learning" },
  { src: image4, alt: "Teacher helping students with work", caption: "Dedicated Teachers" },
  { src: image1, alt: "Students playing sports", caption: "Sports & Recreation" },
  { src: image2, alt: "School prayer time", caption: "Spiritual Growth" },
  { src: image3, alt: "Mathematics lesson", caption: "Academic Excellence" },
  { src: image4, alt: "One-on-one learning", caption: "Personalized Attention" },
];

export function GallerySection() {
  const [selectedImage, setSelectedImage] = useState<{ src: string; alt: string; caption: string } | null>(null);

  return (
    <section id="gallery" className="py-20 md:py-32 bg-accent/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4" data-testid="text-gallery-title">
            Life at <span className="text-primary">Harmony</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto" data-testid="text-gallery-subtitle">
            Take a glimpse into the vibrant learning environment where our students thrive every day.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {galleryImages.map((image, index) => (
            <div
              key={index}
              className="group relative overflow-hidden rounded-lg cursor-pointer aspect-square"
              onClick={() => setSelectedImage(image)}
              data-testid={`gallery-image-${index}`}
            >
              <img
                src={image.src}
                alt={image.alt}
                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="absolute bottom-0 left-0 right-0 p-4">
                  <p className="text-white font-medium text-sm">{image.caption}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <Dialog open={!!selectedImage} onOpenChange={() => setSelectedImage(null)}>
          <DialogContent className="max-w-4xl p-0 overflow-hidden bg-transparent border-0">
            <button
              onClick={() => setSelectedImage(null)}
              className="absolute top-4 right-4 z-10 bg-black/50 text-white rounded-full p-2 hover:bg-black/70 transition-colors"
              data-testid="button-close-lightbox"
            >
              <X className="h-5 w-5" />
            </button>
            {selectedImage && (
              <div className="relative">
                <img
                  src={selectedImage.src}
                  alt={selectedImage.alt}
                  className="w-full h-auto max-h-[80vh] object-contain"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-6">
                  <p className="text-white text-lg font-medium">{selectedImage.caption}</p>
                  <p className="text-white/80 text-sm">{selectedImage.alt}</p>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </section>
  );
}
