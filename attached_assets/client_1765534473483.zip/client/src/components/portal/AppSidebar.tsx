import { Link, useLocation } from "wouter";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import {
  Home,
  Bell,
  FileText,
  Upload,
  BookOpen,
  Users,
  Settings,
  LogOut,
  ClipboardCheck,
  PenTool,
  GraduationCap,
  CheckSquare,
  FileSpreadsheet,
  FolderOpen,
  BarChart3,
  UserPlus,
  Calendar,
  UserCheck,
  CalendarDays,
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import logoImage from "@assets/Harmony_Learning_Logo_Design_1765479534667.png";

interface AppSidebarProps {
  userRole: "student" | "teacher" | "admin";
}

export function AppSidebar({ userRole }: AppSidebarProps) {
  const [location] = useLocation();
  const { user } = useAuth();

  const studentMenuItems = [
    { title: "Dashboard", url: "/portal", icon: Home },
    { title: "Announcements", url: "/portal/announcements", icon: Bell },
    { title: "Assignments", url: "/portal/assignments", icon: FileText },
    { title: "Quizzes", url: "/portal/quizzes", icon: BookOpen },
    { title: "Resources", url: "/portal/resources", icon: FolderOpen },
    { title: "My Attendance", url: "/portal/attendance", icon: UserCheck },
    { title: "Calendar", url: "/portal/calendar", icon: CalendarDays },
  ];

  const teacherMenuItems = [
    { title: "Dashboard", url: "/portal", icon: Home },
    { title: "Announcements", url: "/portal/announcements", icon: Bell },
    { title: "Assignments", url: "/portal/assignments", icon: FileText },
    { title: "Submissions", url: "/portal/submissions", icon: Upload },
    { title: "Quizzes", url: "/portal/quizzes", icon: BookOpen },
    { title: "Quiz Builder", url: "/portal/quiz-builder", icon: PenTool },
    { title: "Gradebook", url: "/portal/gradebook", icon: FileSpreadsheet },
    { title: "Resources", url: "/portal/resources", icon: FolderOpen },
    { title: "Attendance", url: "/portal/attendance", icon: UserCheck },
    { title: "Calendar", url: "/portal/calendar", icon: CalendarDays },
  ];

  const adminMenuItems = [
    { title: "Dashboard", url: "/portal", icon: Home },
    { title: "Student Management", url: "/portal/students", icon: GraduationCap },
    { title: "Teacher Management", url: "/portal/teachers", icon: Users },
    { title: "Enrollments", url: "/portal/enrollments", icon: ClipboardCheck },
    { title: "Announcements", url: "/portal/announcements", icon: Bell },
    { title: "Analytics", url: "/portal/analytics", icon: BarChart3 },
    { title: "Class Management", url: "/portal/class-management", icon: Calendar },
    { title: "Bulk Import", url: "/portal/bulk-import", icon: UserPlus },
    { title: "Gradebook", url: "/portal/gradebook", icon: FileSpreadsheet },
    { title: "Resources", url: "/portal/resources", icon: FolderOpen },
    { title: "Attendance", url: "/portal/attendance", icon: UserCheck },
    { title: "Calendar", url: "/portal/calendar", icon: CalendarDays },
  ];

  const menuItems = 
    userRole === "admin" ? adminMenuItems :
    userRole === "teacher" ? teacherMenuItems :
    studentMenuItems;

  const roleLabel = 
    userRole === "admin" ? "Administrator" :
    userRole === "teacher" ? "Teacher Portal" :
    "Student Portal";

  return (
    <Sidebar>
      <SidebarHeader className="p-4 border-b">
        <Link href="/" className="flex items-center gap-3">
          <img 
            src={logoImage} 
            alt="Harmony Learning Institute" 
            className="h-10 w-auto"
            data-testid="img-sidebar-logo"
          />
          <div className="flex flex-col">
            <span className="font-semibold text-sm">Harmony Learning</span>
            <span className="text-xs text-muted-foreground">{roleLabel}</span>
          </div>
        </Link>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton 
                    asChild 
                    isActive={location === item.url}
                    data-testid={`nav-${item.title.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    <Link href={item.url}>
                      <item.icon className="h-4 w-4" />
                      <span>{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="p-4 border-t">
        <div className="flex items-center gap-3 mb-3">
          <Avatar className="h-9 w-9">
            <AvatarImage src={user?.profileImageUrl || undefined} />
            <AvatarFallback className="bg-primary text-primary-foreground text-sm">
              {user?.firstName?.[0] || user?.email?.[0]?.toUpperCase() || "U"}
            </AvatarFallback>
          </Avatar>
          <div className="flex flex-col flex-1 min-w-0">
            <span className="text-sm font-medium truncate">
              {user?.firstName && user?.lastName 
                ? `${user.firstName} ${user.lastName}` 
                : user?.email || "User"}
            </span>
            <span className="text-xs text-muted-foreground capitalize">{userRole}</span>
          </div>
        </div>
        <Button 
          variant="outline" 
          size="sm" 
          className="w-full" 
          asChild
          data-testid="button-logout"
        >
          <a href="/api/logout">
            <LogOut className="h-4 w-4 mr-2" />
            Sign Out
          </a>
        </Button>
      </SidebarFooter>
    </Sidebar>
  );
}
