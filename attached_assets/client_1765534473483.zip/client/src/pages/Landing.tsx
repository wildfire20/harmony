import { Header } from "@/components/public/Header";
import { HeroSection } from "@/components/public/HeroSection";
import { AboutSection } from "@/components/public/AboutSection";
import { GallerySection } from "@/components/public/GallerySection";
import { ProgramsSection } from "@/components/public/ProgramsSection";
import { EnrollmentSection } from "@/components/public/EnrollmentSection";
import { Footer } from "@/components/public/Footer";

export default function Landing() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <HeroSection />
        <AboutSection />
        <GallerySection />
        <ProgramsSection />
        <EnrollmentSection />
      </main>
      <Footer />
    </div>
  );
}
