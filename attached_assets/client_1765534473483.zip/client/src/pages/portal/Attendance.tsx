import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { format } from "date-fns";
import { Calendar, Check, X, Clock, Users } from "lucide-react";
import type { User } from "@shared/schema";

type AttendanceRecord = {
  id: string;
  studentId: string;
  studentName?: string;
  studentNumber?: string;
  date: string;
  status: string;
  grade: string;
  classGroup: string;
  notes?: string;
};

type AttendanceStatus = "present" | "absent" | "late" | "excused";

export default function Attendance() {
  const { toast } = useToast();
  const [selectedDate, setSelectedDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [selectedGrade, setSelectedGrade] = useState<string>("");
  const [selectedClass, setSelectedClass] = useState<string>("");
  const [attendanceRecords, setAttendanceRecords] = useState<Record<string, AttendanceStatus>>({});

  const { data: currentUser } = useQuery<User>({
    queryKey: ["/api/auth/user"],
  });

  const { data: students, isLoading: studentsLoading } = useQuery<User[]>({
    queryKey: ["/api/users", { role: "student", grade: selectedGrade, classGroup: selectedClass }],
    enabled: !!selectedGrade,
  });

  const { data: existingRecords, isLoading: recordsLoading } = useQuery<AttendanceRecord[]>({
    queryKey: ["/api/attendance", { date: selectedDate, grade: selectedGrade, classGroup: selectedClass }],
    enabled: !!selectedDate && !!selectedGrade,
  });

  const submitMutation = useMutation({
    mutationFn: async (records: any[]) => {
      return apiRequest("POST", "/api/attendance", { records });
    },
    onSuccess: () => {
      toast({ title: "Attendance saved successfully" });
      queryClient.invalidateQueries({ queryKey: ["/api/attendance"] });
      setAttendanceRecords({});
    },
    onError: () => {
      toast({ title: "Failed to save attendance", variant: "destructive" });
    },
  });

  const isStudent = currentUser?.role === "student";

  const grades = ["Preschool", "Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5", "Grade 6"];
  const classes = ["A", "B", "C"];

  const handleStatusChange = (studentId: string, status: AttendanceStatus) => {
    setAttendanceRecords(prev => ({
      ...prev,
      [studentId]: status,
    }));
  };

  const handleSubmit = () => {
    if (!selectedGrade) {
      toast({ title: "Please select a grade", variant: "destructive" });
      return;
    }

    const records = Object.entries(attendanceRecords).map(([studentId, status]) => ({
      studentId,
      date: selectedDate,
      status,
      grade: selectedGrade,
      classGroup: selectedClass || "A",
    }));

    if (records.length === 0) {
      toast({ title: "No attendance records to save", variant: "destructive" });
      return;
    }

    submitMutation.mutate(records);
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, { variant: "default" | "secondary" | "destructive" | "outline"; icon: any }> = {
      present: { variant: "default", icon: Check },
      absent: { variant: "destructive", icon: X },
      late: { variant: "secondary", icon: Clock },
      excused: { variant: "outline", icon: Calendar },
    };
    const config = variants[status] || variants.present;
    const Icon = config.icon;
    return (
      <Badge variant={config.variant} className="gap-1">
        <Icon className="h-3 w-3" />
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  if (isStudent) {
    return (
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-2xl font-bold">My Attendance</h1>
          <p className="text-muted-foreground">View your attendance records</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Attendance History
            </CardTitle>
          </CardHeader>
          <CardContent>
            {recordsLoading ? (
              <p className="text-muted-foreground">Loading...</p>
            ) : existingRecords && existingRecords.length > 0 ? (
              <div className="space-y-3">
                {existingRecords.map((record) => (
                  <div
                    key={record.id}
                    className="flex items-center justify-between p-3 rounded-lg border"
                    data-testid={`attendance-record-${record.id}`}
                  >
                    <span className="font-medium">{format(new Date(record.date), "MMMM d, yyyy")}</span>
                    {getStatusBadge(record.status)}
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground">No attendance records found</p>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Attendance Tracking</h1>
        <p className="text-muted-foreground">Record and manage student attendance</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Record Attendance</CardTitle>
          <CardDescription>Select date, grade, and class to record attendance</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            <div className="space-y-2">
              <Label>Date</Label>
              <Input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                data-testid="input-attendance-date"
              />
            </div>
            <div className="space-y-2">
              <Label>Grade</Label>
              <Select value={selectedGrade} onValueChange={setSelectedGrade}>
                <SelectTrigger data-testid="select-grade">
                  <SelectValue placeholder="Select grade" />
                </SelectTrigger>
                <SelectContent>
                  {grades.map((grade) => (
                    <SelectItem key={grade} value={grade}>
                      {grade}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Class</Label>
              <Select value={selectedClass} onValueChange={setSelectedClass}>
                <SelectTrigger data-testid="select-class">
                  <SelectValue placeholder="All classes" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Classes</SelectItem>
                  {classes.map((cls) => (
                    <SelectItem key={cls} value={cls}>
                      Class {cls}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {selectedGrade && (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-4">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Students - {selectedGrade}
              </CardTitle>
              <CardDescription>
                Click status buttons to mark attendance
              </CardDescription>
            </div>
            <Button
              onClick={handleSubmit}
              disabled={submitMutation.isPending || Object.keys(attendanceRecords).length === 0}
              data-testid="button-save-attendance"
            >
              {submitMutation.isPending ? "Saving..." : "Save Attendance"}
            </Button>
          </CardHeader>
          <CardContent>
            {studentsLoading ? (
              <p className="text-muted-foreground">Loading students...</p>
            ) : students && students.length > 0 ? (
              <div className="space-y-3">
                {students.map((student) => (
                  <div
                    key={student.id}
                    className="flex items-center justify-between p-3 rounded-lg border"
                    data-testid={`student-row-${student.id}`}
                  >
                    <div>
                      <p className="font-medium">{student.firstName} {student.lastName}</p>
                      <p className="text-sm text-muted-foreground">{student.studentNumber}</p>
                    </div>
                    <div className="flex gap-2">
                      {(["present", "absent", "late", "excused"] as AttendanceStatus[]).map((status) => (
                        <Button
                          key={status}
                          size="sm"
                          variant={attendanceRecords[student.id] === status ? "default" : "outline"}
                          onClick={() => handleStatusChange(student.id, status)}
                          data-testid={`button-status-${status}-${student.id}`}
                        >
                          {status.charAt(0).toUpperCase()}
                        </Button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground">No students found for this grade/class</p>
            )}
          </CardContent>
        </Card>
      )}

      {existingRecords && existingRecords.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Today's Records</CardTitle>
            <CardDescription>Previously recorded attendance for {selectedDate}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {existingRecords.map((record) => (
                <div
                  key={record.id}
                  className="flex items-center justify-between p-3 rounded-lg border"
                  data-testid={`existing-record-${record.id}`}
                >
                  <div>
                    <p className="font-medium">{record.studentName}</p>
                    <p className="text-sm text-muted-foreground">{record.studentNumber}</p>
                  </div>
                  {getStatusBadge(record.status)}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
