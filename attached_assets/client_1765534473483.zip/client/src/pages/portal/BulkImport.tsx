import { useState, useRef } from "react";
import { useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Upload, FileSpreadsheet, CheckCircle, AlertCircle, Download } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const GRADES = ["Pre-K", "Kindergarten", "Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5", "Grade 6"];

interface ParsedUser {
  firstName: string;
  lastName: string;
  email?: string;
  grade: string;
  classGroup?: string;
  studentNumber?: string;
  valid: boolean;
  error?: string;
}

export default function BulkImport() {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [parsedUsers, setParsedUsers] = useState<ParsedUser[]>([]);
  const [defaultGrade, setDefaultGrade] = useState("");
  const [defaultClassGroup, setDefaultClassGroup] = useState("");

  const importMutation = useMutation({
    mutationFn: async (users: ParsedUser[]) => {
      const validUsers = users.filter(u => u.valid).map(u => ({
        firstName: u.firstName,
        lastName: u.lastName,
        email: u.email,
        grade: u.grade || defaultGrade,
        classGroup: u.classGroup || defaultClassGroup,
        studentNumber: u.studentNumber,
        role: "student",
      }));

      return apiRequest("/api/users/bulk-import", {
        method: "POST",
        body: JSON.stringify({ users: validUsers }),
        headers: { "Content-Type": "application/json" },
      });
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      toast({ title: `Successfully imported ${data.created} students` });
      setParsedUsers([]);
    },
    onError: () => {
      toast({ title: "Failed to import students", variant: "destructive" });
    },
  });

  const parseCSV = (content: string): ParsedUser[] => {
    const lines = content.trim().split("\n");
    if (lines.length < 2) return [];

    const headers = lines[0].toLowerCase().split(",").map(h => h.trim());
    const firstNameIdx = headers.findIndex(h => h.includes("first") && h.includes("name"));
    const lastNameIdx = headers.findIndex(h => h.includes("last") && h.includes("name"));
    const emailIdx = headers.findIndex(h => h.includes("email"));
    const gradeIdx = headers.findIndex(h => h === "grade" || h.includes("grade"));
    const classIdx = headers.findIndex(h => h.includes("class"));
    const studentNumIdx = headers.findIndex(h => h.includes("student") && h.includes("number"));

    return lines.slice(1).map((line, idx) => {
      const values = line.split(",").map(v => v.trim().replace(/^["']|["']$/g, ""));
      
      const firstName = firstNameIdx >= 0 ? values[firstNameIdx] : "";
      const lastName = lastNameIdx >= 0 ? values[lastNameIdx] : "";
      const email = emailIdx >= 0 ? values[emailIdx] : undefined;
      const grade = gradeIdx >= 0 ? values[gradeIdx] : "";
      const classGroup = classIdx >= 0 ? values[classIdx] : undefined;
      const studentNumber = studentNumIdx >= 0 ? values[studentNumIdx] : undefined;

      let valid = true;
      let error = "";

      if (!firstName || !lastName) {
        valid = false;
        error = "Missing name";
      }

      return {
        firstName,
        lastName,
        email,
        grade,
        classGroup,
        studentNumber,
        valid,
        error,
      };
    }).filter(u => u.firstName || u.lastName);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const users = parseCSV(content);
      setParsedUsers(users);
    };
    reader.readAsText(file);
  };

  const downloadTemplate = () => {
    const template = "First Name,Last Name,Email,Grade,Class,Student Number\nJohn,Doe,john@example.com,Grade 1,A,STU001\nJane,Smith,jane@example.com,Grade 1,A,STU002";
    const blob = new Blob([template], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "student-import-template.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  const validCount = parsedUsers.filter(u => u.valid).length;
  const invalidCount = parsedUsers.filter(u => !u.valid).length;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold" data-testid="text-bulk-import-title">Bulk Student Import</h1>
        <p className="text-muted-foreground">Import multiple students from a CSV file</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileSpreadsheet className="w-5 h-5" />
              Upload CSV File
            </CardTitle>
            <CardDescription>
              Upload a CSV file with student information. Download the template to see the required format.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Default Grade (for missing values)</Label>
              <Select value={defaultGrade} onValueChange={setDefaultGrade}>
                <SelectTrigger data-testid="select-default-grade">
                  <SelectValue placeholder="Select default grade" />
                </SelectTrigger>
                <SelectContent>
                  {GRADES.map(g => (
                    <SelectItem key={g} value={g}>{g}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Default Class Group (optional)</Label>
              <Input
                value={defaultClassGroup}
                onChange={(e) => setDefaultClassGroup(e.target.value)}
                placeholder="e.g., A"
                data-testid="input-default-class"
              />
            </div>

            <input
              type="file"
              accept=".csv"
              ref={fileInputRef}
              onChange={handleFileUpload}
              className="hidden"
              data-testid="input-csv-file"
            />

            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={downloadTemplate}
                data-testid="button-download-template"
              >
                <Download className="w-4 h-4 mr-2" />
                Download Template
              </Button>
              <Button
                onClick={() => fileInputRef.current?.click()}
                data-testid="button-upload-csv"
              >
                <Upload className="w-4 h-4 mr-2" />
                Upload CSV
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Import Summary</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {parsedUsers.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No data uploaded yet. Upload a CSV file to preview.
              </div>
            ) : (
              <>
                <div className="flex gap-4">
                  <div className="flex-1 p-4 bg-muted/50 rounded-lg text-center">
                    <div className="text-2xl font-bold text-green-600">{validCount}</div>
                    <div className="text-sm text-muted-foreground">Valid Records</div>
                  </div>
                  <div className="flex-1 p-4 bg-muted/50 rounded-lg text-center">
                    <div className="text-2xl font-bold text-red-600">{invalidCount}</div>
                    <div className="text-sm text-muted-foreground">Invalid Records</div>
                  </div>
                </div>

                <Button
                  className="w-full"
                  disabled={validCount === 0 || importMutation.isPending}
                  onClick={() => importMutation.mutate(parsedUsers)}
                  data-testid="button-import"
                >
                  {importMutation.isPending ? "Importing..." : `Import ${validCount} Students`}
                </Button>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      {parsedUsers.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Preview</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Status</TableHead>
                    <TableHead>First Name</TableHead>
                    <TableHead>Last Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Grade</TableHead>
                    <TableHead>Class</TableHead>
                    <TableHead>Student #</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {parsedUsers.map((user, idx) => (
                    <TableRow key={idx} data-testid={`row-preview-${idx}`}>
                      <TableCell>
                        {user.valid ? (
                          <CheckCircle className="w-5 h-5 text-green-600" />
                        ) : (
                          <div className="flex items-center gap-1">
                            <AlertCircle className="w-5 h-5 text-red-600" />
                            <span className="text-xs text-red-600">{user.error}</span>
                          </div>
                        )}
                      </TableCell>
                      <TableCell>{user.firstName}</TableCell>
                      <TableCell>{user.lastName}</TableCell>
                      <TableCell>{user.email || "-"}</TableCell>
                      <TableCell>
                        {user.grade ? (
                          <Badge variant="outline">{user.grade}</Badge>
                        ) : defaultGrade ? (
                          <Badge variant="secondary">{defaultGrade} (default)</Badge>
                        ) : (
                          "-"
                        )}
                      </TableCell>
                      <TableCell>{user.classGroup || defaultClassGroup || "-"}</TableCell>
                      <TableCell>{user.studentNumber || "Auto-generated"}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
