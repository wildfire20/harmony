import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { format, isSameMonth, startOfMonth, endOfMonth, eachDayOfInterval, isToday } from "date-fns";
import { Calendar as CalendarIcon, Plus, ChevronLeft, ChevronRight, Trash2 } from "lucide-react";
import type { User } from "@shared/schema";

type CalendarEventData = {
  id: string;
  title: string;
  description?: string | null;
  startDate: string;
  endDate?: string | null;
  allDay?: boolean | null;
  eventType: string | null;
  targetGrade?: string | null;
  targetClass?: string | null;
  createdBy: string;
  createdAt?: string | null;
};

type EventFormData = {
  title: string;
  description?: string;
  eventType: string;
  startDate: string;
  endDate?: string;
  targetGrade?: string;
  targetClass?: string;
};

const eventTypeColors: Record<string, string> = {
  holiday: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
  exam: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200",
  meeting: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
  event: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
  deadline: "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200",
  other: "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200",
};

export default function Calendar() {
  const { toast } = useToast();
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState<CalendarEventData | null>(null);

  const form = useForm<EventFormData>({
    defaultValues: {
      title: "",
      description: "",
      eventType: "event",
      startDate: format(new Date(), "yyyy-MM-dd"),
      endDate: "",
      targetGrade: "",
      targetClass: "",
    },
  });

  const { data: currentUser } = useQuery<User>({
    queryKey: ["/api/auth/user"],
  });

  const { data: events, isLoading } = useQuery<CalendarEventData[]>({
    queryKey: ["/api/calendar"],
  });

  const createMutation = useMutation({
    mutationFn: async (data: EventFormData) => {
      return apiRequest("POST", "/api/calendar", data);
    },
    onSuccess: () => {
      toast({ title: "Event created successfully" });
      queryClient.invalidateQueries({ queryKey: ["/api/calendar"] });
      setIsDialogOpen(false);
      form.reset();
    },
    onError: () => {
      toast({ title: "Failed to create event", variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("DELETE", `/api/calendar/${id}`);
    },
    onSuccess: () => {
      toast({ title: "Event deleted successfully" });
      queryClient.invalidateQueries({ queryKey: ["/api/calendar"] });
      setSelectedEvent(null);
    },
    onError: () => {
      toast({ title: "Failed to delete event", variant: "destructive" });
    },
  });

  const canManageEvents = currentUser?.role === "admin" || currentUser?.role === "teacher";

  const daysInMonth = eachDayOfInterval({
    start: startOfMonth(currentMonth),
    end: endOfMonth(currentMonth),
  });

  const firstDayOfMonth = startOfMonth(currentMonth).getDay();
  const paddingDays = Array(firstDayOfMonth).fill(null);

  const getEventsForDay = (date: Date) => {
    if (!events) return [];
    return events.filter((event) => {
      const eventStart = new Date(event.startDate);
      const eventEnd = event.endDate ? new Date(event.endDate) : eventStart;
      return date >= eventStart && date <= eventEnd;
    });
  };

  const handleSubmit = (data: EventFormData) => {
    createMutation.mutate(data);
  };

  const grades = ["", "Preschool", "Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5", "Grade 6"];
  const classes = ["", "A", "B", "C"];
  const eventTypes = ["holiday", "exam", "meeting", "event", "deadline", "other"];

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold">School Calendar</h1>
          <p className="text-muted-foreground">View and manage school events</p>
        </div>
        {canManageEvents && (
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button data-testid="button-add-event">
                <Plus className="h-4 w-4 mr-2" />
                Add Event
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Create Event</DialogTitle>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="title"
                    rules={{ required: "Title is required" }}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Title</FormLabel>
                        <FormControl>
                          <Input {...field} data-testid="input-event-title" placeholder="Event title" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea {...field} data-testid="input-event-description" placeholder="Event details..." />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="eventType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Type</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger data-testid="select-event-type">
                              <SelectValue placeholder="Select type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {eventTypes.map((type) => (
                              <SelectItem key={type} value={type}>
                                {type.charAt(0).toUpperCase() + type.slice(1)}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="startDate"
                      rules={{ required: "Start date is required" }}
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Start Date</FormLabel>
                          <FormControl>
                            <Input type="date" {...field} data-testid="input-start-date" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="endDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>End Date</FormLabel>
                          <FormControl>
                            <Input type="date" {...field} data-testid="input-end-date" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="targetGrade"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Target Grade</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="All grades" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {grades.map((grade) => (
                                <SelectItem key={grade || "all"} value={grade || "all"}>
                                  {grade || "All Grades"}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="targetClass"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Target Class</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="All classes" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {classes.map((cls) => (
                                <SelectItem key={cls || "all"} value={cls || "all"}>
                                  {cls ? `Class ${cls}` : "All Classes"}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <Button type="submit" className="w-full" disabled={createMutation.isPending} data-testid="button-create-event">
                    {createMutation.isPending ? "Creating..." : "Create Event"}
                  </Button>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        )}
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-4">
          <CardTitle className="flex items-center gap-2">
            <CalendarIcon className="h-5 w-5" />
            {format(currentMonth, "MMMM yyyy")}
          </CardTitle>
          <div className="flex gap-2">
            <Button
              size="icon"
              variant="outline"
              onClick={() => setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1))}
              data-testid="button-prev-month"
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button
              size="icon"
              variant="outline"
              onClick={() => setCurrentMonth(new Date())}
              data-testid="button-today"
            >
              <CalendarIcon className="h-4 w-4" />
            </Button>
            <Button
              size="icon"
              variant="outline"
              onClick={() => setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1))}
              data-testid="button-next-month"
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <p className="text-muted-foreground">Loading calendar...</p>
          ) : (
            <div className="grid grid-cols-7 gap-px bg-border rounded-lg overflow-hidden">
              {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
                <div key={day} className="bg-muted p-2 text-center text-sm font-medium">
                  {day}
                </div>
              ))}
              {paddingDays.map((_, index) => (
                <div key={`padding-${index}`} className="bg-background p-2 min-h-24" />
              ))}
              {daysInMonth.map((date) => {
                const dayEvents = getEventsForDay(date);
                return (
                  <div
                    key={date.toISOString()}
                    className={`bg-background p-2 min-h-24 ${isToday(date) ? "ring-2 ring-primary ring-inset" : ""}`}
                    data-testid={`calendar-day-${format(date, "yyyy-MM-dd")}`}
                  >
                    <div className={`text-sm ${isToday(date) ? "font-bold text-primary" : ""}`}>
                      {format(date, "d")}
                    </div>
                    <div className="space-y-1 mt-1">
                      {dayEvents.slice(0, 3).map((event) => (
                        <button
                          key={event.id}
                          className={`w-full text-left text-xs p-1 rounded truncate ${eventTypeColors[event.eventType || "other"] || eventTypeColors.other}`}
                          onClick={() => setSelectedEvent(event)}
                          data-testid={`event-${event.id}`}
                        >
                          {event.title}
                        </button>
                      ))}
                      {dayEvents.length > 3 && (
                        <p className="text-xs text-muted-foreground">+{dayEvents.length - 3} more</p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {selectedEvent && (
        <Dialog open={!!selectedEvent} onOpenChange={() => setSelectedEvent(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="flex items-center justify-between gap-4">
                {selectedEvent.title}
                {canManageEvents && (
                  <Button
                    size="icon"
                    variant="destructive"
                    onClick={() => deleteMutation.mutate(selectedEvent.id)}
                    disabled={deleteMutation.isPending}
                    data-testid="button-delete-event"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                )}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <Badge className={eventTypeColors[selectedEvent.eventType || "other"] || eventTypeColors.other}>
                {selectedEvent.eventType || "other"}
              </Badge>
              <div>
                <Label className="text-muted-foreground">Date</Label>
                <p>
                  {format(new Date(selectedEvent.startDate), "MMMM d, yyyy")}
                  {selectedEvent.endDate && selectedEvent.endDate !== selectedEvent.startDate && (
                    <> - {format(new Date(selectedEvent.endDate), "MMMM d, yyyy")}</>
                  )}
                </p>
              </div>
              {selectedEvent.description && (
                <div>
                  <Label className="text-muted-foreground">Description</Label>
                  <p>{selectedEvent.description}</p>
                </div>
              )}
              {selectedEvent.targetGrade && (
                <div>
                  <Label className="text-muted-foreground">Target</Label>
                  <p>
                    {selectedEvent.targetGrade}
                    {selectedEvent.targetClass && ` - Class ${selectedEvent.targetClass}`}
                  </p>
                </div>
              )}
            </div>
          </DialogContent>
        </Dialog>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Upcoming Events</CardTitle>
          <CardDescription>Events scheduled for this month</CardDescription>
        </CardHeader>
        <CardContent>
          {events && events.length > 0 ? (
            <div className="space-y-3">
              {events
                .filter((e) => isSameMonth(new Date(e.startDate), currentMonth))
                .sort((a, b) => new Date(a.startDate).getTime() - new Date(b.startDate).getTime())
                .map((event) => (
                  <div
                    key={event.id}
                    className="flex items-center justify-between p-3 rounded-lg border hover-elevate cursor-pointer"
                    onClick={() => setSelectedEvent(event)}
                    data-testid={`upcoming-event-${event.id}`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-2 h-2 rounded-full ${eventTypeColors[event.eventType || "other"]?.split(" ")[0] || "bg-gray-500"}`} />
                      <div>
                        <p className="font-medium">{event.title}</p>
                        <p className="text-sm text-muted-foreground">
                          {format(new Date(event.startDate), "MMM d")}
                          {event.endDate && event.endDate !== event.startDate && (
                            <> - {format(new Date(event.endDate), "MMM d")}</>
                          )}
                        </p>
                      </div>
                    </div>
                    <Badge variant="outline">{event.eventType || "other"}</Badge>
                  </div>
                ))}
            </div>
          ) : (
            <p className="text-muted-foreground">No events this month</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
