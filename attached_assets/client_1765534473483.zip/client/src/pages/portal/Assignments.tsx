import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { FileText, Plus, Calendar, Clock, Upload, Loader2, CheckCircle2, AlertCircle, Download } from "lucide-react";
import type { Assignment, Submission } from "@shared/schema";

const assignmentSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters"),
  instructions: z.string().min(10, "Instructions must be at least 10 characters"),
  subject: z.string().min(1, "Please select a subject"),
  grade: z.string().min(1, "Please select a grade"),
  classGroup: z.string().optional(),
  dueDate: z.string().min(1, "Please set a due date"),
  maxPoints: z.coerce.number().min(1).max(1000).default(100),
});

type AssignmentFormData = z.infer<typeof assignmentSchema>;

const subjects = ["Mathematics", "English", "Science", "Social Studies", "Art", "Music", "Physical Education"];
const grades = ["Preschool", "Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5", "Grade 6"];

export default function Assignments() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [submitDialogOpen, setSubmitDialogOpen] = useState(false);
  const [selectedAssignment, setSelectedAssignment] = useState<Assignment | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const isTeacher = user?.role === "teacher" || user?.role === "admin";

  const { data: assignments, isLoading } = useQuery<Assignment[]>({
    queryKey: ["/api/assignments"],
  });

  const { data: submissions } = useQuery<Submission[]>({
    queryKey: ["/api/submissions"],
    enabled: !isTeacher,
  });

  const form = useForm<AssignmentFormData>({
    resolver: zodResolver(assignmentSchema),
    defaultValues: {
      title: "",
      instructions: "",
      subject: "",
      grade: "",
      classGroup: "",
      dueDate: "",
      maxPoints: 100,
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: AssignmentFormData) => {
      return apiRequest("POST", "/api/assignments", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/assignments"] });
      toast({ title: "Assignment Created", description: "Your assignment has been posted." });
      setDialogOpen(false);
      form.reset();
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create assignment.", variant: "destructive" });
    },
  });

  const submitMutation = useMutation({
    mutationFn: async ({ assignmentId, file }: { assignmentId: string; file: File }) => {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("assignmentId", assignmentId);
      
      const response = await fetch("/api/submissions", {
        method: "POST",
        body: formData,
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error("Failed to submit");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/submissions"] });
      toast({ title: "Submitted!", description: "Your work has been submitted successfully." });
      setSubmitDialogOpen(false);
      setSelectedFile(null);
      setSelectedAssignment(null);
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to submit assignment.", variant: "destructive" });
    },
  });

  const onSubmit = (data: AssignmentFormData) => {
    createMutation.mutate(data);
  };

  const handleSubmitWork = () => {
    if (!selectedAssignment || !selectedFile) return;
    submitMutation.mutate({ assignmentId: selectedAssignment.id, file: selectedFile });
  };

  const getSubmissionStatus = (assignmentId: string) => {
    return submissions?.find((s) => s.assignmentId === assignmentId);
  };

  const now = new Date();
  const pendingAssignments = assignments?.filter((a) => {
    const submission = getSubmissionStatus(a.id);
    return !submission && new Date(a.dueDate) > now;
  }) || [];
  
  const submittedAssignments = assignments?.filter((a) => {
    const submission = getSubmissionStatus(a.id);
    return submission && !submission.grade;
  }) || [];
  
  const gradedAssignments = assignments?.filter((a) => {
    const submission = getSubmissionStatus(a.id);
    return submission?.grade !== null && submission?.grade !== undefined;
  }) || [];

  const formatDate = (date: Date | string) => {
    return new Date(date).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const getDaysUntilDue = (dueDate: Date | string) => {
    const due = new Date(dueDate);
    const diff = due.getTime() - now.getTime();
    return Math.ceil(diff / (1000 * 60 * 60 * 24));
  };

  const AssignmentCard = ({ assignment, showSubmit = false }: { assignment: Assignment; showSubmit?: boolean }) => {
    const daysLeft = getDaysUntilDue(assignment.dueDate);
    const isOverdue = daysLeft < 0;
    const submission = getSubmissionStatus(assignment.id);

    return (
      <Card data-testid={`card-assignment-${assignment.id}`}>
        <CardHeader className="pb-3">
          <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2">
            <div className="flex-1">
              <div className="flex flex-wrap items-center gap-2 mb-1">
                <Badge variant="secondary">{assignment.subject}</Badge>
                <Badge variant="outline">{assignment.grade}</Badge>
              </div>
              <CardTitle className="text-lg">{assignment.title}</CardTitle>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              {submission?.grade !== null && submission?.grade !== undefined ? (
                <Badge variant="default" className="bg-green-600">
                  <CheckCircle2 className="h-3 w-3 mr-1" />
                  {submission.grade}/{assignment.maxPoints}
                </Badge>
              ) : submission ? (
                <Badge variant="secondary">
                  <CheckCircle2 className="h-3 w-3 mr-1" />
                  Submitted
                </Badge>
              ) : (
                <Badge variant={isOverdue ? "destructive" : daysLeft <= 2 ? "secondary" : "outline"}>
                  <Clock className="h-3 w-3 mr-1" />
                  {isOverdue ? "Overdue" : `${daysLeft}d left`}
                </Badge>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground text-sm mb-4 line-clamp-2">{assignment.instructions}</p>
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <span className="flex items-center gap-1">
                <Calendar className="h-4 w-4" />
                Due: {formatDate(assignment.dueDate)}
              </span>
              <span>{assignment.maxPoints} pts</span>
            </div>
            {showSubmit && !submission && (
              <Button 
                size="sm"
                onClick={() => {
                  setSelectedAssignment(assignment);
                  setSubmitDialogOpen(true);
                }}
                data-testid={`button-submit-${assignment.id}`}
              >
                <Upload className="h-4 w-4 mr-2" />
                Submit Work
              </Button>
            )}
            {submission && (
              <Button variant="outline" size="sm" asChild>
                <a href={submission.fileUrl} target="_blank" rel="noopener noreferrer">
                  <Download className="h-4 w-4 mr-2" />
                  View Submission
                </a>
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold" data-testid="text-assignments-title">
            Assignments
          </h1>
          <p className="text-muted-foreground mt-1">
            {isTeacher ? "Manage and create assignments" : "View and submit your assignments"}
          </p>
        </div>
        {isTeacher && (
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button data-testid="button-create-assignment">
                <Plus className="h-4 w-4 mr-2" />
                New Assignment
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Create Assignment</DialogTitle>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Title</FormLabel>
                        <FormControl>
                          <Input placeholder="Assignment title" {...field} data-testid="input-assignment-title" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="subject"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Subject</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger data-testid="select-subject">
                                <SelectValue placeholder="Select" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {subjects.map((s) => (
                                <SelectItem key={s} value={s}>{s}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="grade"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Grade</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger data-testid="select-grade">
                                <SelectValue placeholder="Select" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {grades.map((g) => (
                                <SelectItem key={g} value={g}>{g}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <FormField
                    control={form.control}
                    name="instructions"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Instructions</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Describe the assignment..."
                            className="min-h-[100px]"
                            {...field}
                            data-testid="textarea-instructions"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="dueDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Due Date</FormLabel>
                          <FormControl>
                            <Input type="datetime-local" {...field} data-testid="input-due-date" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="maxPoints"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Max Points</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} data-testid="input-max-points" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <div className="flex justify-end gap-2 pt-4">
                    <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button type="submit" disabled={createMutation.isPending} data-testid="button-submit-assignment">
                      {createMutation.isPending ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          Creating...
                        </>
                      ) : (
                        "Create Assignment"
                      )}
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {isTeacher ? (
        isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-32 w-full" />
            ))}
          </div>
        ) : assignments?.length === 0 ? (
          <Card>
            <CardContent className="py-16 text-center">
              <FileText className="h-12 w-12 mx-auto mb-4 text-muted-foreground opacity-50" />
              <h3 className="text-lg font-semibold mb-2">No Assignments Yet</h3>
              <p className="text-muted-foreground">Create your first assignment to get started.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {assignments?.map((assignment) => (
              <AssignmentCard key={assignment.id} assignment={assignment} />
            ))}
          </div>
        )
      ) : (
        <Tabs defaultValue="pending" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="pending" data-testid="tab-pending">
              Pending ({pendingAssignments.length})
            </TabsTrigger>
            <TabsTrigger value="submitted" data-testid="tab-submitted">
              Submitted ({submittedAssignments.length})
            </TabsTrigger>
            <TabsTrigger value="graded" data-testid="tab-graded">
              Graded ({gradedAssignments.length})
            </TabsTrigger>
          </TabsList>
          <TabsContent value="pending" className="space-y-4 mt-4">
            {isLoading ? (
              <Skeleton className="h-32 w-full" />
            ) : pendingAssignments.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <CheckCircle2 className="h-10 w-10 mx-auto mb-3 text-green-500" />
                  <h3 className="font-semibold mb-1">All Caught Up!</h3>
                  <p className="text-sm text-muted-foreground">No pending assignments.</p>
                </CardContent>
              </Card>
            ) : (
              pendingAssignments.map((a) => <AssignmentCard key={a.id} assignment={a} showSubmit />)
            )}
          </TabsContent>
          <TabsContent value="submitted" className="space-y-4 mt-4">
            {submittedAssignments.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <Upload className="h-10 w-10 mx-auto mb-3 text-muted-foreground opacity-50" />
                  <h3 className="font-semibold mb-1">No Submitted Work</h3>
                  <p className="text-sm text-muted-foreground">Submit assignments to see them here.</p>
                </CardContent>
              </Card>
            ) : (
              submittedAssignments.map((a) => <AssignmentCard key={a.id} assignment={a} />)
            )}
          </TabsContent>
          <TabsContent value="graded" className="space-y-4 mt-4">
            {gradedAssignments.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <AlertCircle className="h-10 w-10 mx-auto mb-3 text-muted-foreground opacity-50" />
                  <h3 className="font-semibold mb-1">No Graded Work</h3>
                  <p className="text-sm text-muted-foreground">Graded assignments will appear here.</p>
                </CardContent>
              </Card>
            ) : (
              gradedAssignments.map((a) => <AssignmentCard key={a.id} assignment={a} />)
            )}
          </TabsContent>
        </Tabs>
      )}

      <Dialog open={submitDialogOpen} onOpenChange={setSubmitDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Submit Assignment</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Upload your work for: <strong>{selectedAssignment?.title}</strong>
            </p>
            <div className="border-2 border-dashed rounded-lg p-8 text-center">
              <input
                type="file"
                onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
                className="hidden"
                id="file-upload"
                accept=".pdf,.doc,.docx,.jpg,.jpeg,.png,.zip"
                data-testid="input-file-upload"
              />
              <label htmlFor="file-upload" className="cursor-pointer">
                <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                {selectedFile ? (
                  <p className="text-sm font-medium">{selectedFile.name}</p>
                ) : (
                  <>
                    <p className="text-sm font-medium">Click to upload</p>
                    <p className="text-xs text-muted-foreground">PDF, DOC, Images, ZIP (max 10MB)</p>
                  </>
                )}
              </label>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setSubmitDialogOpen(false)}>
                Cancel
              </Button>
              <Button 
                onClick={handleSubmitWork} 
                disabled={!selectedFile || submitMutation.isPending}
                data-testid="button-confirm-submit"
              >
                {submitMutation.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Uploading...
                  </>
                ) : (
                  "Submit"
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
