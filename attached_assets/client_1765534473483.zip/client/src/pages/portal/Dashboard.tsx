import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/hooks/useAuth";
import { Bell, FileText, BookOpen, Clock, ChevronRight, CheckCircle2, AlertCircle } from "lucide-react";
import { Link } from "wouter";
import type { Announcement, Assignment, Quiz } from "@shared/schema";

export default function Dashboard() {
  const { user } = useAuth();

  const { data: announcements, isLoading: announcementsLoading } = useQuery<Announcement[]>({
    queryKey: ["/api/announcements"],
  });

  const { data: assignments, isLoading: assignmentsLoading } = useQuery<Assignment[]>({
    queryKey: ["/api/assignments"],
  });

  const { data: quizzes, isLoading: quizzesLoading } = useQuery<Quiz[]>({
    queryKey: ["/api/quizzes"],
  });

  const recentAnnouncements = announcements?.slice(0, 3) || [];
  const upcomingAssignments = assignments?.filter(a => new Date(a.dueDate) > new Date()).slice(0, 3) || [];
  const availableQuizzes = quizzes?.filter(q => q.isPublished).slice(0, 3) || [];

  const isTeacher = user?.role === "teacher";
  const isAdmin = user?.role === "admin";

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl md:text-3xl font-bold" data-testid="text-dashboard-title">
          Welcome back, {user?.firstName || "User"}!
        </h1>
        <p className="text-muted-foreground mt-1" data-testid="text-dashboard-subtitle">
          {isAdmin 
            ? "Manage your school from your admin dashboard."
            : isTeacher 
              ? "Manage your classes and students from here."
              : "Here's what's happening in your classes today."}
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card data-testid="card-announcements-count">
          <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
            <CardTitle className="text-sm font-medium">Announcements</CardTitle>
            <Bell className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {announcementsLoading ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <>
                <div className="text-2xl font-bold">{announcements?.length || 0}</div>
                <p className="text-xs text-muted-foreground">
                  {recentAnnouncements.length} new this week
                </p>
              </>
            )}
          </CardContent>
        </Card>

        <Card data-testid="card-assignments-count">
          <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
            <CardTitle className="text-sm font-medium">
              {isTeacher ? "Active Assignments" : "Pending Assignments"}
            </CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {assignmentsLoading ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <>
                <div className="text-2xl font-bold">{upcomingAssignments.length}</div>
                <p className="text-xs text-muted-foreground">
                  Due this week
                </p>
              </>
            )}
          </CardContent>
        </Card>

        <Card data-testid="card-quizzes-count">
          <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
            <CardTitle className="text-sm font-medium">
              {isTeacher ? "Published Quizzes" : "Available Quizzes"}
            </CardTitle>
            <BookOpen className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {quizzesLoading ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <>
                <div className="text-2xl font-bold">{availableQuizzes.length}</div>
                <p className="text-xs text-muted-foreground">
                  Ready to take
                </p>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card data-testid="card-recent-announcements">
          <CardHeader>
            <div className="flex items-center justify-between gap-4">
              <div>
                <CardTitle>Recent Announcements</CardTitle>
                <CardDescription>Stay updated with school news</CardDescription>
              </div>
              <Button variant="ghost" size="sm" asChild>
                <Link href="/portal/announcements">
                  View All
                  <ChevronRight className="ml-1 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {announcementsLoading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <Skeleton key={i} className="h-16 w-full" />
                ))}
              </div>
            ) : recentAnnouncements.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Bell className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>No announcements yet</p>
              </div>
            ) : (
              <div className="space-y-3">
                {recentAnnouncements.map((announcement) => (
                  <div 
                    key={announcement.id} 
                    className="flex items-start gap-3 p-3 rounded-lg bg-muted/50"
                    data-testid={`announcement-${announcement.id}`}
                  >
                    <div className="h-2 w-2 rounded-full bg-primary mt-2 shrink-0" />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-medium text-sm truncate">{announcement.title}</h4>
                        <Badge variant="secondary" className="text-xs shrink-0">
                          {announcement.scope}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground line-clamp-2">
                        {announcement.content}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card data-testid="card-upcoming-assignments">
          <CardHeader>
            <div className="flex items-center justify-between gap-4">
              <div>
                <CardTitle>
                  {isTeacher ? "Recent Assignments" : "Upcoming Assignments"}
                </CardTitle>
                <CardDescription>
                  {isTeacher ? "Assignments you've created" : "Don't miss your deadlines"}
                </CardDescription>
              </div>
              <Button variant="ghost" size="sm" asChild>
                <Link href="/portal/assignments">
                  View All
                  <ChevronRight className="ml-1 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {assignmentsLoading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <Skeleton key={i} className="h-16 w-full" />
                ))}
              </div>
            ) : upcomingAssignments.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <CheckCircle2 className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>No upcoming assignments</p>
              </div>
            ) : (
              <div className="space-y-3">
                {upcomingAssignments.map((assignment) => {
                  const dueDate = new Date(assignment.dueDate);
                  const isOverdue = dueDate < new Date();
                  const daysUntilDue = Math.ceil((dueDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24));

                  return (
                    <div 
                      key={assignment.id} 
                      className="flex items-center gap-3 p-3 rounded-lg bg-muted/50"
                      data-testid={`assignment-${assignment.id}`}
                    >
                      <div className={`h-10 w-10 rounded-lg flex items-center justify-center shrink-0 ${
                        isOverdue ? "bg-destructive/10" : "bg-primary/10"
                      }`}>
                        <FileText className={`h-5 w-5 ${
                          isOverdue ? "text-destructive" : "text-primary"
                        }`} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-sm truncate">{assignment.title}</h4>
                        <p className="text-xs text-muted-foreground">{assignment.subject}</p>
                      </div>
                      <div className="text-right shrink-0">
                        <Badge variant={isOverdue ? "destructive" : daysUntilDue <= 2 ? "secondary" : "outline"}>
                          <Clock className="h-3 w-3 mr-1" />
                          {isOverdue ? "Overdue" : `${daysUntilDue}d left`}
                        </Badge>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
