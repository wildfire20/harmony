import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Plus, Search, Pencil, Users } from "lucide-react";
import type { User } from "@shared/schema";

const GRADES = ["Grade R", "Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5", "Grade 6", "Grade 7", "Grade 8", "Grade 9"];
const CLASSES = ["Class A", "Class B", "Class C"];

export default function TeacherManagement() {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingTeacher, setEditingTeacher] = useState<User | null>(null);
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    allocatedGrades: [] as string[],
    allocatedClasses: [] as string[],
  });

  const { data: users = [], isLoading } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });

  const teachers = users.filter((u) => u.role === "teacher");

  const filteredTeachers = teachers.filter((teacher) => {
    const matchesSearch =
      searchTerm === "" ||
      `${teacher.firstName} ${teacher.lastName}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
      teacher.email?.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSearch;
  });

  const createTeacherMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      return apiRequest("POST", "/api/admin/teachers", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      toast({ title: "Success", description: "Teacher account created successfully" });
      resetForm();
      setDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const updateTeacherMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<typeof formData> }) => {
      return apiRequest("PATCH", `/api/admin/teachers/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      toast({ title: "Success", description: "Teacher updated successfully" });
      resetForm();
      setDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const resetForm = () => {
    setFormData({
      firstName: "",
      lastName: "",
      email: "",
      password: "",
      allocatedGrades: [],
      allocatedClasses: [],
    });
    setEditingTeacher(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingTeacher) {
      const updateData: any = { ...formData };
      if (!updateData.password) delete updateData.password;
      updateTeacherMutation.mutate({ id: editingTeacher.id, data: updateData });
    } else {
      createTeacherMutation.mutate(formData);
    }
  };

  const handleEdit = (teacher: User) => {
    setEditingTeacher(teacher);
    setFormData({
      firstName: teacher.firstName || "",
      lastName: teacher.lastName || "",
      email: teacher.email || "",
      password: "",
      allocatedGrades: teacher.allocatedGrades || [],
      allocatedClasses: teacher.allocatedClasses || [],
    });
    setDialogOpen(true);
  };

  const toggleGrade = (grade: string) => {
    setFormData((prev) => ({
      ...prev,
      allocatedGrades: prev.allocatedGrades.includes(grade)
        ? prev.allocatedGrades.filter((g) => g !== grade)
        : [...prev.allocatedGrades, grade],
    }));
  };

  const toggleClass = (cls: string) => {
    setFormData((prev) => ({
      ...prev,
      allocatedClasses: prev.allocatedClasses.includes(cls)
        ? prev.allocatedClasses.filter((c) => c !== cls)
        : [...prev.allocatedClasses, cls],
    }));
  };

  const formatAssignedClasses = (teacher: User) => {
    const grades = teacher.allocatedGrades || [];
    const classes = teacher.allocatedClasses || [];
    if (grades.length === 0 && classes.length === 0) return "None";
    
    const assignments: string[] = [];
    grades.forEach((grade) => {
      const relevantClasses = classes.length > 0 ? classes : ["All Classes"];
      relevantClasses.forEach((cls) => {
        assignments.push(`${grade} - ${cls}`);
      });
    });
    
    if (assignments.length === 0) {
      return classes.join(", ") || "None";
    }
    return assignments.slice(0, 3).join(", ") + (assignments.length > 3 ? ` +${assignments.length - 3} more` : "");
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Users className="h-6 w-6" />
            Teacher Management
          </h1>
          <p className="text-muted-foreground">Manage teacher accounts and class assignments</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={(open) => { setDialogOpen(open); if (!open) resetForm(); }}>
          <DialogTrigger asChild>
            <Button data-testid="button-add-teacher">
              <Plus className="h-4 w-4 mr-2" />
              Add Teacher
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>{editingTeacher ? "Edit Teacher" : "Add New Teacher"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="firstName">First Name</Label>
                  <Input
                    id="firstName"
                    data-testid="input-teacher-firstname"
                    value={formData.firstName}
                    onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lastName">Last Name</Label>
                  <Input
                    id="lastName"
                    data-testid="input-teacher-lastname"
                    value={formData.lastName}
                    onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                    required
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  data-testid="input-teacher-email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  required
                  placeholder="teacher@harmonylearning.edu"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">
                  {editingTeacher ? "New Password (leave blank to keep current)" : "Password"}
                </Label>
                <Input
                  id="password"
                  type="password"
                  data-testid="input-teacher-password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  required={!editingTeacher}
                  placeholder={editingTeacher ? "Leave blank to keep current password" : "Enter password"}
                />
              </div>
              <div className="space-y-2">
                <Label>Assigned Grades</Label>
                <div className="grid grid-cols-5 gap-2">
                  {GRADES.map((grade) => (
                    <div key={grade} className="flex items-center space-x-2">
                      <Checkbox
                        id={`grade-${grade}`}
                        checked={formData.allocatedGrades.includes(grade)}
                        onCheckedChange={() => toggleGrade(grade)}
                        data-testid={`checkbox-grade-${grade.replace(/\s+/g, '-').toLowerCase()}`}
                      />
                      <label htmlFor={`grade-${grade}`} className="text-xs cursor-pointer">
                        {grade.replace("Grade ", "G")}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
              <div className="space-y-2">
                <Label>Assigned Classes</Label>
                <div className="grid grid-cols-3 gap-2">
                  {CLASSES.map((cls) => (
                    <div key={cls} className="flex items-center space-x-2">
                      <Checkbox
                        id={`class-${cls}`}
                        checked={formData.allocatedClasses.includes(cls)}
                        onCheckedChange={() => toggleClass(cls)}
                        data-testid={`checkbox-class-${cls.replace(/\s+/g, '-').toLowerCase()}`}
                      />
                      <label htmlFor={`class-${cls}`} className="text-sm cursor-pointer">
                        {cls}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => { setDialogOpen(false); resetForm(); }}>
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  data-testid="button-save-teacher"
                  disabled={createTeacherMutation.isPending || updateTeacherMutation.isPending}
                >
                  {(createTeacherMutation.isPending || updateTeacherMutation.isPending) ? "Saving..." : (editingTeacher ? "Update" : "Create")}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader className="pb-4">
          <div className="flex items-center gap-4">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search teachers..."
                data-testid="input-search-teachers"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8 text-muted-foreground">Loading teachers...</div>
          ) : filteredTeachers.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              {teachers.length === 0 ? "No teachers found. Add a teacher to get started." : "No teachers match your search."}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Teacher</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>Assigned Classes</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredTeachers.map((teacher) => (
                  <TableRow key={teacher.id} data-testid={`row-teacher-${teacher.id}`}>
                    <TableCell className="font-medium">
                      {teacher.firstName} {teacher.lastName}
                    </TableCell>
                    <TableCell>{teacher.email || "-"}</TableCell>
                    <TableCell>
                      <Badge variant={teacher.role === "admin" ? "default" : "secondary"}>
                        {teacher.role === "admin" ? "Admin" : "Teacher"}
                      </Badge>
                    </TableCell>
                    <TableCell className="max-w-[250px] truncate">
                      {formatAssignedClasses(teacher)}
                    </TableCell>
                    <TableCell>
                      <Badge variant={teacher.isApproved ? "default" : "secondary"}>
                        {teacher.isApproved ? "Active" : "Inactive"}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => handleEdit(teacher)}
                        data-testid={`button-edit-teacher-${teacher.id}`}
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
