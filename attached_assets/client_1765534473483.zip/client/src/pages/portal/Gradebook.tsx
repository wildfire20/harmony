import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, Download, Trash2, Edit, FileSpreadsheet } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { User } from "@shared/schema";

const GRADES = ["Pre-K", "Kindergarten", "Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5", "Grade 6"];
const ASSESSMENT_TYPES = ["test", "exam", "assignment", "quiz", "homework", "project"];

export default function Gradebook() {
  const { toast } = useToast();
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [filterGrade, setFilterGrade] = useState<string>("");
  const [formData, setFormData] = useState({
    studentId: "",
    subject: "",
    assessmentType: "test",
    assessmentName: "",
    maxMarks: 100,
    obtainedMarks: 0,
    term: "",
    comments: "",
    grade: "",
    classGroup: "",
  });

  const { data: marks = [], isLoading } = useQuery<any[]>({
    queryKey: ["/api/gradebook", filterGrade],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (filterGrade && filterGrade !== "all") {
        params.append("grade", filterGrade);
      }
      const response = await fetch(`/api/gradebook?${params.toString()}`, {
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to fetch gradebook");
      return response.json();
    },
  });

  const { data: students = [] } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });

  const studentList = students.filter(s => s.role === "student");

  const createMarkMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      return apiRequest("/api/gradebook", {
        method: "POST",
        body: JSON.stringify(data),
        headers: { "Content-Type": "application/json" },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/gradebook"] });
      setIsAddOpen(false);
      setFormData({
        studentId: "",
        subject: "",
        assessmentType: "test",
        assessmentName: "",
        maxMarks: 100,
        obtainedMarks: 0,
        term: "",
        comments: "",
        grade: "",
        classGroup: "",
      });
      toast({ title: "Mark added successfully" });
    },
    onError: () => {
      toast({ title: "Failed to add mark", variant: "destructive" });
    },
  });

  const deleteMarkMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest(`/api/gradebook/${id}`, { method: "DELETE" });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/gradebook"] });
      toast({ title: "Mark deleted successfully" });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createMarkMutation.mutate(formData);
  };

  const exportToCSV = () => {
    const headers = ["Student", "Subject", "Assessment", "Type", "Obtained", "Max", "Grade", "Term", "Comments"];
    const rows = marks.map(m => [
      m.studentName,
      m.subject,
      m.assessmentName,
      m.assessmentType,
      m.obtainedMarks,
      m.maxMarks,
      m.grade,
      m.term || "",
      m.comments || "",
    ]);

    const csvContent = [headers, ...rows].map(r => r.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `gradebook-${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold" data-testid="text-gradebook-title">Gradebook</h1>
          <p className="text-muted-foreground">Manage and track student marks privately</p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <Select value={filterGrade} onValueChange={setFilterGrade}>
            <SelectTrigger className="w-40" data-testid="select-filter-grade">
              <SelectValue placeholder="All Grades" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Grades</SelectItem>
              {GRADES.map(g => (
                <SelectItem key={g} value={g}>{g}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Button variant="outline" onClick={exportToCSV} data-testid="button-export-csv">
            <Download className="w-4 h-4 mr-2" />
            Export CSV
          </Button>

          <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
            <DialogTrigger asChild>
              <Button data-testid="button-add-mark">
                <Plus className="w-4 h-4 mr-2" />
                Add Mark
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>Add New Mark</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label>Student</Label>
                  <Select
                    value={formData.studentId}
                    onValueChange={(v) => {
                      const student = studentList.find(s => s.id === v);
                      setFormData({ 
                        ...formData, 
                        studentId: v,
                        grade: student?.grade || "",
                        classGroup: student?.classGroup || "",
                      });
                    }}
                  >
                    <SelectTrigger data-testid="select-student">
                      <SelectValue placeholder="Select student" />
                    </SelectTrigger>
                    <SelectContent>
                      {studentList.map(s => (
                        <SelectItem key={s.id} value={s.id}>
                          {s.firstName} {s.lastName} ({s.studentNumber})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Subject</Label>
                    <Input
                      value={formData.subject}
                      onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                      placeholder="e.g., Mathematics"
                      data-testid="input-subject"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Assessment Type</Label>
                    <Select
                      value={formData.assessmentType}
                      onValueChange={(v) => setFormData({ ...formData, assessmentType: v })}
                    >
                      <SelectTrigger data-testid="select-assessment-type">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {ASSESSMENT_TYPES.map(t => (
                          <SelectItem key={t} value={t}>{t.charAt(0).toUpperCase() + t.slice(1)}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Assessment Name</Label>
                  <Input
                    value={formData.assessmentName}
                    onChange={(e) => setFormData({ ...formData, assessmentName: e.target.value })}
                    placeholder="e.g., Mid-Term Test"
                    data-testid="input-assessment-name"
                  />
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label>Obtained Marks</Label>
                    <Input
                      type="number"
                      value={formData.obtainedMarks}
                      onChange={(e) => setFormData({ ...formData, obtainedMarks: parseInt(e.target.value) || 0 })}
                      data-testid="input-obtained-marks"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Max Marks</Label>
                    <Input
                      type="number"
                      value={formData.maxMarks}
                      onChange={(e) => setFormData({ ...formData, maxMarks: parseInt(e.target.value) || 100 })}
                      data-testid="input-max-marks"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Term</Label>
                    <Input
                      value={formData.term}
                      onChange={(e) => setFormData({ ...formData, term: e.target.value })}
                      placeholder="Term 1"
                      data-testid="input-term"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Comments</Label>
                  <Textarea
                    value={formData.comments}
                    onChange={(e) => setFormData({ ...formData, comments: e.target.value })}
                    placeholder="Optional comments..."
                    data-testid="input-comments"
                  />
                </div>

                <Button type="submit" className="w-full" disabled={createMarkMutation.isPending} data-testid="button-submit-mark">
                  {createMarkMutation.isPending ? "Saving..." : "Save Mark"}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5" />
            Marks Record
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8 text-muted-foreground">Loading marks...</div>
          ) : marks.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No marks recorded yet. Click "Add Mark" to get started.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Student</TableHead>
                    <TableHead>Subject</TableHead>
                    <TableHead>Assessment</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Score</TableHead>
                    <TableHead>Percentage</TableHead>
                    <TableHead>Term</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {marks.map((mark) => {
                    const percentage = Math.round((mark.obtainedMarks / mark.maxMarks) * 100);
                    return (
                      <TableRow key={mark.id} data-testid={`row-mark-${mark.id}`}>
                        <TableCell>
                          <div>
                            <div className="font-medium">{mark.studentName}</div>
                            <div className="text-xs text-muted-foreground">{mark.studentNumber}</div>
                          </div>
                        </TableCell>
                        <TableCell>{mark.subject}</TableCell>
                        <TableCell>{mark.assessmentName}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{mark.assessmentType}</Badge>
                        </TableCell>
                        <TableCell>{mark.obtainedMarks}/{mark.maxMarks}</TableCell>
                        <TableCell>
                          <Badge variant={percentage >= 50 ? "default" : "destructive"}>
                            {percentage}%
                          </Badge>
                        </TableCell>
                        <TableCell>{mark.term || "-"}</TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => deleteMarkMutation.mutate(mark.id)}
                            data-testid={`button-delete-mark-${mark.id}`}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
