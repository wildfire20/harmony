import { useState, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Plus, Download, Trash2, FileText, File, Image, FileVideo, Upload } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { User, Resource } from "@shared/schema";

const GRADES = ["Pre-K", "Kindergarten", "Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5", "Grade 6"];

function getFileIcon(fileType?: string | null) {
  if (!fileType) return <File className="w-8 h-8" />;
  if (fileType.startsWith("image/")) return <Image className="w-8 h-8" />;
  if (fileType.startsWith("video/")) return <FileVideo className="w-8 h-8" />;
  return <FileText className="w-8 h-8" />;
}

function formatFileSize(bytes?: number | null) {
  if (!bytes) return "Unknown size";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export default function Resources() {
  const { toast } = useToast();
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    subject: "",
    grade: "",
    classGroup: "",
  });

  const { data: currentUser } = useQuery<User>({
    queryKey: ["/api/auth/user"],
  });

  const { data: resources = [], isLoading } = useQuery<Resource[]>({
    queryKey: ["/api/resources"],
  });

  const isTeacherOrAdmin = currentUser?.role === "teacher" || currentUser?.role === "admin";

  const uploadMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const response = await fetch("/api/resources", {
        method: "POST",
        body: formData,
        credentials: "include",
        headers: {
        },
      });
      if (!response.ok) {
        const error = await response.json().catch(() => ({ message: "Upload failed" }));
        throw new Error(error.message || "Upload failed");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/resources"] });
      setIsUploadOpen(false);
      setSelectedFile(null);
      setFormData({ title: "", description: "", subject: "", grade: "", classGroup: "" });
      toast({ title: "Resource uploaded successfully" });
    },
    onError: () => {
      toast({ title: "Failed to upload resource", variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest(`/api/resources/${id}`, { method: "DELETE" });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/resources"] });
      toast({ title: "Resource deleted successfully" });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFile) {
      toast({ title: "Please select a file", variant: "destructive" });
      return;
    }

    const data = new FormData();
    data.append("file", selectedFile);
    data.append("title", formData.title);
    data.append("description", formData.description);
    data.append("subject", formData.subject);
    data.append("grade", formData.grade);
    data.append("classGroup", formData.classGroup);

    uploadMutation.mutate(data);
  };

  const handleDownload = async (resource: Resource) => {
    try {
      const response = await fetch(`/api/resources/${resource.id}/download`, {
        credentials: "include",
      });
      const data = await response.json();
      window.open(data.downloadUrl, "_blank");
    } catch (error) {
      toast({ title: "Download failed", variant: "destructive" });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold" data-testid="text-resources-title">Learning Resources</h1>
          <p className="text-muted-foreground">
            {isTeacherOrAdmin
              ? "Upload and manage learning materials for students"
              : "Access learning materials shared by your teachers"}
          </p>
        </div>

        {isTeacherOrAdmin && (
          <Dialog open={isUploadOpen} onOpenChange={setIsUploadOpen}>
            <DialogTrigger asChild>
              <Button data-testid="button-upload-resource">
                <Plus className="w-4 h-4 mr-2" />
                Upload Resource
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>Upload Learning Resource</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label>File</Label>
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
                    className="hidden"
                    data-testid="input-file"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    className="w-full"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    {selectedFile ? selectedFile.name : "Choose File"}
                  </Button>
                </div>

                <div className="space-y-2">
                  <Label>Title</Label>
                  <Input
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="Resource title"
                    required
                    data-testid="input-title"
                  />
                </div>

                <div className="space-y-2">
                  <Label>Description</Label>
                  <Textarea
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Describe the resource..."
                    data-testid="input-description"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Subject</Label>
                    <Input
                      value={formData.subject}
                      onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                      placeholder="e.g., Mathematics"
                      required
                      data-testid="input-subject"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Grade</Label>
                    <Select
                      value={formData.grade}
                      onValueChange={(v) => setFormData({ ...formData, grade: v })}
                    >
                      <SelectTrigger data-testid="select-grade">
                        <SelectValue placeholder="Select grade" />
                      </SelectTrigger>
                      <SelectContent>
                        {GRADES.map(g => (
                          <SelectItem key={g} value={g}>{g}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <Button type="submit" className="w-full" disabled={uploadMutation.isPending} data-testid="button-submit-upload">
                  {uploadMutation.isPending ? "Uploading..." : "Upload Resource"}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {isLoading ? (
        <div className="text-center py-8 text-muted-foreground">Loading resources...</div>
      ) : resources.length === 0 ? (
        <Card>
          <CardContent className="text-center py-12">
            <FileText className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">No Resources Available</h3>
            <p className="text-muted-foreground">
              {isTeacherOrAdmin
                ? "Upload learning materials for your students."
                : "Your teachers haven't uploaded any resources yet."}
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {resources.map((resource) => (
            <Card key={resource.id} className="hover-elevate" data-testid={`card-resource-${resource.id}`}>
              <CardHeader className="pb-3">
                <div className="flex items-start gap-3">
                  <div className="p-2 bg-muted rounded-md">
                    {getFileIcon(resource.fileType)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <CardTitle className="text-base truncate">{resource.title}</CardTitle>
                    <p className="text-sm text-muted-foreground truncate">{resource.fileName}</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {resource.description && (
                  <p className="text-sm text-muted-foreground line-clamp-2">{resource.description}</p>
                )}

                <div className="flex flex-wrap gap-2">
                  <Badge variant="outline">{resource.subject}</Badge>
                  <Badge variant="secondary">{resource.grade}</Badge>
                  {resource.classGroup && <Badge>{resource.classGroup}</Badge>}
                </div>

                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>{formatFileSize(resource.fileSize)}</span>
                  <span>{resource.downloadCount || 0} downloads</span>
                </div>

                <div className="flex gap-2">
                  <Button
                    className="flex-1"
                    variant="outline"
                    onClick={() => handleDownload(resource)}
                    data-testid={`button-download-${resource.id}`}
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                  {isTeacherOrAdmin && (
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => deleteMutation.mutate(resource.id)}
                      data-testid={`button-delete-${resource.id}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
