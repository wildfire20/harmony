import { useState } from "react";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from "@/components/ui/form";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Plus, Trash2, Loader2, CheckCircle2, GripVertical } from "lucide-react";

const questionSchema = z.object({
  questionText: z.string().min(5, "Question must be at least 5 characters"),
  questionType: z.enum(["multiple_choice", "true_false"]),
  options: z.array(z.string()).min(2, "At least 2 options required"),
  correctAnswer: z.string().min(1, "Select correct answer"),
  points: z.coerce.number().min(1).default(1),
});

const quizSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters"),
  description: z.string().optional(),
  subject: z.string().min(1, "Please select a subject"),
  grade: z.string().min(1, "Please select a grade"),
  timeLimit: z.coerce.number().optional(),
  randomizeQuestions: z.boolean().default(false),
  isPublished: z.boolean().default(false),
  questions: z.array(questionSchema).min(1, "Add at least one question"),
});

type QuizFormData = z.infer<typeof quizSchema>;

const subjects = ["Mathematics", "English", "Science", "Social Studies", "Art", "Music", "Physical Education"];
const grades = ["Preschool", "Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5", "Grade 6"];

export default function QuizBuilder() {
  const { toast } = useToast();
  const [step, setStep] = useState<"settings" | "questions" | "review">("settings");

  const form = useForm<QuizFormData>({
    resolver: zodResolver(quizSchema),
    defaultValues: {
      title: "",
      description: "",
      subject: "",
      grade: "",
      timeLimit: undefined,
      randomizeQuestions: false,
      isPublished: false,
      questions: [
        {
          questionText: "",
          questionType: "multiple_choice",
          options: ["", "", "", ""],
          correctAnswer: "",
          points: 1,
        },
      ],
    },
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "questions",
  });

  const createMutation = useMutation({
    mutationFn: async (data: QuizFormData) => {
      return apiRequest("POST", "/api/quizzes", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/quizzes"] });
      toast({ title: "Quiz Created!", description: "Your quiz has been saved successfully." });
      form.reset();
      setStep("settings");
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create quiz.", variant: "destructive" });
    },
  });

  const onSubmit = (data: QuizFormData) => {
    createMutation.mutate(data);
  };

  const addQuestion = () => {
    append({
      questionText: "",
      questionType: "multiple_choice",
      options: ["", "", "", ""],
      correctAnswer: "",
      points: 1,
    });
  };

  const handleQuestionTypeChange = (index: number, type: "multiple_choice" | "true_false") => {
    const currentQuestions = form.getValues("questions");
    if (type === "true_false") {
      form.setValue(`questions.${index}.options`, ["True", "False"]);
    } else {
      form.setValue(`questions.${index}.options`, ["", "", "", ""]);
    }
    form.setValue(`questions.${index}.questionType`, type);
    form.setValue(`questions.${index}.correctAnswer`, "");
  };

  const totalPoints = form.watch("questions")?.reduce((sum, q) => sum + (q.points || 1), 0) || 0;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl md:text-3xl font-bold" data-testid="text-quiz-builder-title">
          Quiz Builder
        </h1>
        <p className="text-muted-foreground mt-1">
          Create interactive quizzes for your students
        </p>
      </div>

      <Tabs value={step} onValueChange={(v) => setStep(v as typeof step)}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="settings" data-testid="tab-settings">1. Settings</TabsTrigger>
          <TabsTrigger value="questions" data-testid="tab-questions">2. Questions</TabsTrigger>
          <TabsTrigger value="review" data-testid="tab-review">3. Review</TabsTrigger>
        </TabsList>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <TabsContent value="settings" className="space-y-6 mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Quiz Settings</CardTitle>
                  <CardDescription>Configure the basic settings for your quiz</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <FormField
                    control={form.control}
                    name="title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Quiz Title</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g., Math Chapter 5 Quiz" {...field} data-testid="input-quiz-title" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description (Optional)</FormLabel>
                        <FormControl>
                          <Textarea placeholder="Brief description of the quiz..." {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="subject"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Subject</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger data-testid="select-quiz-subject">
                                <SelectValue placeholder="Select" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {subjects.map((s) => (
                                <SelectItem key={s} value={s}>{s}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="grade"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Grade</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger data-testid="select-quiz-grade">
                                <SelectValue placeholder="Select" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {grades.map((g) => (
                                <SelectItem key={g} value={g}>{g}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="timeLimit"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Time Limit (minutes)</FormLabel>
                          <FormControl>
                            <Input type="number" placeholder="No limit" {...field} />
                          </FormControl>
                          <FormDescription>Leave empty for no time limit</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="randomizeQuestions"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                          <FormControl>
                            <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Randomize Questions</FormLabel>
                            <FormDescription>Shuffle question order for each student</FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />
                  </div>
                </CardContent>
              </Card>

              <div className="flex justify-end">
                <Button type="button" onClick={() => setStep("questions")} data-testid="button-next-to-questions">
                  Next: Add Questions
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="questions" className="space-y-6 mt-6">
              {fields.map((field, index) => (
                <Card key={field.id} data-testid={`card-question-${index}`}>
                  <CardHeader>
                    <div className="flex items-center justify-between gap-4">
                      <div className="flex items-center gap-2">
                        <GripVertical className="h-5 w-5 text-muted-foreground" />
                        <CardTitle className="text-base">Question {index + 1}</CardTitle>
                      </div>
                      {fields.length > 1 && (
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          onClick={() => remove(index)}
                          data-testid={`button-remove-question-${index}`}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <FormField
                      control={form.control}
                      name={`questions.${index}.questionText`}
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Question</FormLabel>
                          <FormControl>
                            <Textarea placeholder="Enter your question..." {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name={`questions.${index}.questionType`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Question Type</FormLabel>
                            <Select 
                              onValueChange={(value) => handleQuestionTypeChange(index, value as "multiple_choice" | "true_false")} 
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select type" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="multiple_choice">Multiple Choice</SelectItem>
                                <SelectItem value="true_false">True/False</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name={`questions.${index}.points`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Points</FormLabel>
                            <FormControl>
                              <Input type="number" min="1" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    {form.watch(`questions.${index}.questionType`) !== "true_false" && (
                      <div className="space-y-2">
                        <FormLabel>Answer Options</FormLabel>
                        {form.watch(`questions.${index}.options`)?.map((_, optIndex) => (
                          <FormField
                            key={optIndex}
                            control={form.control}
                            name={`questions.${index}.options.${optIndex}`}
                            render={({ field }) => (
                              <FormItem>
                                <FormControl>
                                  <Input placeholder={`Option ${optIndex + 1}`} {...field} />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                        ))}
                      </div>
                    )}

                    <FormField
                      control={form.control}
                      name={`questions.${index}.correctAnswer`}
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Correct Answer</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select correct answer" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {form.watch(`questions.${index}.options`)?.filter(Boolean).map((option, i) => (
                                <SelectItem key={i} value={option}>{option}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>
              ))}

              <Button type="button" variant="outline" onClick={addQuestion} className="w-full" data-testid="button-add-question">
                <Plus className="h-4 w-4 mr-2" />
                Add Question
              </Button>

              <div className="flex justify-between gap-4">
                <Button type="button" variant="outline" onClick={() => setStep("settings")}>
                  Back to Settings
                </Button>
                <Button type="button" onClick={() => setStep("review")} data-testid="button-next-to-review">
                  Review Quiz
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="review" className="space-y-6 mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Quiz Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-muted-foreground">Title:</span>
                      <p className="font-medium">{form.watch("title") || "Not set"}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Subject:</span>
                      <p className="font-medium">{form.watch("subject") || "Not set"}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Grade:</span>
                      <p className="font-medium">{form.watch("grade") || "Not set"}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Questions:</span>
                      <p className="font-medium">{fields.length}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Total Points:</span>
                      <p className="font-medium">{totalPoints}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Time Limit:</span>
                      <p className="font-medium">{form.watch("timeLimit") ? `${form.watch("timeLimit")} min` : "No limit"}</p>
                    </div>
                  </div>

                  <FormField
                    control={form.control}
                    name="isPublished"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4 bg-muted/50">
                        <FormControl>
                          <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Publish immediately</FormLabel>
                          <FormDescription>Students will be able to take this quiz right away</FormDescription>
                        </div>
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>

              <div className="flex justify-between gap-4">
                <Button type="button" variant="outline" onClick={() => setStep("questions")}>
                  Back to Questions
                </Button>
                <Button type="submit" disabled={createMutation.isPending} data-testid="button-create-quiz">
                  {createMutation.isPending ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Creating...
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="h-4 w-4 mr-2" />
                      Create Quiz
                    </>
                  )}
                </Button>
              </div>
            </TabsContent>
          </form>
        </Form>
      </Tabs>
    </div>
  );
}
