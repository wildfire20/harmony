import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { ClipboardCheck, CheckCircle2, XCircle, Eye, Calendar, Mail, Phone, User, GraduationCap, Loader2 } from "lucide-react";
import type { Enrollment } from "@shared/schema";
import { useState } from "react";

export default function Enrollments() {
  const { toast } = useToast();
  const [selectedEnrollment, setSelectedEnrollment] = useState<Enrollment | null>(null);

  const { data: enrollments, isLoading } = useQuery<Enrollment[]>({
    queryKey: ["/api/enrollments"],
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: "approved" | "rejected" }) => {
      return apiRequest("PATCH", `/api/enrollments/${id}`, { status });
    },
    onSuccess: (_, { status }) => {
      queryClient.invalidateQueries({ queryKey: ["/api/enrollments"] });
      toast({
        title: status === "approved" ? "Application Approved" : "Application Rejected",
        description: status === "approved" 
          ? "The student has been enrolled successfully." 
          : "The application has been rejected.",
      });
      setSelectedEnrollment(null);
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update application.", variant: "destructive" });
    },
  });

  const pendingEnrollments = enrollments?.filter((e) => e.status === "pending") || [];
  const processedEnrollments = enrollments?.filter((e) => e.status !== "pending") || [];

  const formatDate = (date: Date | string | null) => {
    if (!date) return "N/A";
    return new Date(date).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  };

  const StatusBadge = ({ status }: { status: string }) => {
    switch (status) {
      case "approved":
        return <Badge className="bg-green-600"><CheckCircle2 className="h-3 w-3 mr-1" />Approved</Badge>;
      case "rejected":
        return <Badge variant="destructive"><XCircle className="h-3 w-3 mr-1" />Rejected</Badge>;
      default:
        return <Badge variant="secondary">Pending</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl md:text-3xl font-bold" data-testid="text-enrollments-title">
          Enrollment Applications
        </h1>
        <p className="text-muted-foreground mt-1">
          Review and manage student enrollment applications
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
            <CardTitle className="text-sm font-medium">Pending</CardTitle>
            <ClipboardCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{pendingEnrollments.length}</div>
            <p className="text-xs text-muted-foreground">Awaiting review</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
            <CardTitle className="text-sm font-medium">Approved</CardTitle>
            <CheckCircle2 className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {enrollments?.filter((e) => e.status === "approved").length || 0}
            </div>
            <p className="text-xs text-muted-foreground">Students enrolled</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
            <CardTitle className="text-sm font-medium">Rejected</CardTitle>
            <XCircle className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {enrollments?.filter((e) => e.status === "rejected").length || 0}
            </div>
            <p className="text-xs text-muted-foreground">Applications declined</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Pending Applications</CardTitle>
          <CardDescription>Applications awaiting your review</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : pendingEnrollments.length === 0 ? (
            <div className="py-12 text-center">
              <ClipboardCheck className="h-10 w-10 mx-auto mb-3 text-muted-foreground opacity-50" />
              <h3 className="font-semibold mb-1">No Pending Applications</h3>
              <p className="text-sm text-muted-foreground">All applications have been processed.</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Student</TableHead>
                  <TableHead>Parent</TableHead>
                  <TableHead>Grade</TableHead>
                  <TableHead>Applied</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pendingEnrollments.map((enrollment) => (
                  <TableRow key={enrollment.id} data-testid={`row-enrollment-${enrollment.id}`}>
                    <TableCell className="font-medium">
                      {enrollment.studentFirstName} {enrollment.studentLastName}
                    </TableCell>
                    <TableCell>
                      {enrollment.parentFirstName} {enrollment.parentLastName}
                    </TableCell>
                    <TableCell>{enrollment.gradeApplying}</TableCell>
                    <TableCell>{formatDate(enrollment.createdAt)}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={() => setSelectedEnrollment(enrollment)}
                              data-testid={`button-view-${enrollment.id}`}
                            >
                              <Eye className="h-4 w-4 mr-1" />
                              View
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-lg">
                            <DialogHeader>
                              <DialogTitle>Enrollment Application</DialogTitle>
                            </DialogHeader>
                            {selectedEnrollment && (
                              <div className="space-y-4">
                                <div className="grid grid-cols-2 gap-4">
                                  <div>
                                    <h4 className="font-semibold text-sm flex items-center gap-2 mb-2">
                                      <User className="h-4 w-4" /> Student Info
                                    </h4>
                                    <p className="text-sm">{selectedEnrollment.studentFirstName} {selectedEnrollment.studentLastName}</p>
                                    <p className="text-sm text-muted-foreground">DOB: {selectedEnrollment.studentDateOfBirth}</p>
                                  </div>
                                  <div>
                                    <h4 className="font-semibold text-sm flex items-center gap-2 mb-2">
                                      <GraduationCap className="h-4 w-4" /> Grade
                                    </h4>
                                    <p className="text-sm">{selectedEnrollment.gradeApplying}</p>
                                    <p className="text-sm text-muted-foreground">
                                      {selectedEnrollment.boardingOption ? "Boarding" : "Day Scholar"}
                                    </p>
                                  </div>
                                </div>
                                <div>
                                  <h4 className="font-semibold text-sm mb-2">Parent/Guardian</h4>
                                  <div className="space-y-1 text-sm">
                                    <p>{selectedEnrollment.parentFirstName} {selectedEnrollment.parentLastName}</p>
                                    <p className="text-muted-foreground flex items-center gap-2">
                                      <Mail className="h-3 w-3" /> {selectedEnrollment.parentEmail}
                                    </p>
                                    <p className="text-muted-foreground flex items-center gap-2">
                                      <Phone className="h-3 w-3" /> {selectedEnrollment.parentPhone}
                                    </p>
                                  </div>
                                </div>
                                {selectedEnrollment.previousSchool && (
                                  <div>
                                    <h4 className="font-semibold text-sm mb-1">Previous School</h4>
                                    <p className="text-sm text-muted-foreground">{selectedEnrollment.previousSchool}</p>
                                  </div>
                                )}
                                {selectedEnrollment.additionalNotes && (
                                  <div>
                                    <h4 className="font-semibold text-sm mb-1">Additional Notes</h4>
                                    <p className="text-sm text-muted-foreground">{selectedEnrollment.additionalNotes}</p>
                                  </div>
                                )}
                                <div className="flex gap-2 pt-4 border-t">
                                  <Button
                                    className="flex-1"
                                    onClick={() => updateMutation.mutate({ id: selectedEnrollment.id, status: "approved" })}
                                    disabled={updateMutation.isPending}
                                    data-testid="button-approve"
                                  >
                                    {updateMutation.isPending ? (
                                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                                    ) : (
                                      <CheckCircle2 className="h-4 w-4 mr-2" />
                                    )}
                                    Approve
                                  </Button>
                                  <Button
                                    variant="destructive"
                                    className="flex-1"
                                    onClick={() => updateMutation.mutate({ id: selectedEnrollment.id, status: "rejected" })}
                                    disabled={updateMutation.isPending}
                                    data-testid="button-reject"
                                  >
                                    {updateMutation.isPending ? (
                                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                                    ) : (
                                      <XCircle className="h-4 w-4 mr-2" />
                                    )}
                                    Reject
                                  </Button>
                                </div>
                              </div>
                            )}
                          </DialogContent>
                        </Dialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {processedEnrollments.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Processed Applications</CardTitle>
            <CardDescription>Previously reviewed applications</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Student</TableHead>
                  <TableHead>Grade</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Reviewed</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {processedEnrollments.map((enrollment) => (
                  <TableRow key={enrollment.id}>
                    <TableCell className="font-medium">
                      {enrollment.studentFirstName} {enrollment.studentLastName}
                    </TableCell>
                    <TableCell>{enrollment.gradeApplying}</TableCell>
                    <TableCell><StatusBadge status={enrollment.status || "pending"} /></TableCell>
                    <TableCell>{formatDate(enrollment.reviewedAt)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
