import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { BookOpen, Clock, CheckCircle2, Play, Trophy, ArrowRight, Loader2 } from "lucide-react";
import type { Quiz, QuizQuestion, QuizAttempt } from "@shared/schema";

export default function Quizzes() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedQuiz, setSelectedQuiz] = useState<Quiz | null>(null);
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [quizStarted, setQuizStarted] = useState(false);
  const [quizResult, setQuizResult] = useState<{ score: number; maxScore: number } | null>(null);

  const isTeacher = user?.role === "teacher" || user?.role === "admin";

  const { data: quizzes, isLoading } = useQuery<Quiz[]>({
    queryKey: ["/api/quizzes"],
  });

  const { data: attempts } = useQuery<QuizAttempt[]>({
    queryKey: ["/api/quiz-attempts"],
    enabled: !isTeacher,
  });

  const startQuizMutation = useMutation({
    mutationFn: async (quizId: string) => {
      const response = await apiRequest("GET", `/api/quizzes/${quizId}/questions`);
      return response as QuizQuestion[];
    },
    onSuccess: (data) => {
      setQuestions(data);
      setQuizStarted(true);
      setCurrentQuestion(0);
      setAnswers({});
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to load quiz.", variant: "destructive" });
    },
  });

  const submitQuizMutation = useMutation({
    mutationFn: async ({ quizId, answers }: { quizId: string; answers: Record<string, string> }) => {
      return apiRequest("POST", "/api/quiz-attempts", { quizId, answers });
    },
    onSuccess: (data: any) => {
      setQuizResult({ score: data.score, maxScore: data.maxScore });
      queryClient.invalidateQueries({ queryKey: ["/api/quiz-attempts"] });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to submit quiz.", variant: "destructive" });
    },
  });

  const getAttemptForQuiz = (quizId: string) => {
    return attempts?.find((a) => a.quizId === quizId);
  };

  const handleStartQuiz = (quiz: Quiz) => {
    setSelectedQuiz(quiz);
    startQuizMutation.mutate(quiz.id);
  };

  const handleSelectAnswer = (questionId: string, answer: string) => {
    setAnswers((prev) => ({ ...prev, [questionId]: answer }));
  };

  const handleNextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion((prev) => prev + 1);
    }
  };

  const handleSubmitQuiz = () => {
    if (!selectedQuiz) return;
    submitQuizMutation.mutate({ quizId: selectedQuiz.id, answers });
  };

  const handleCloseQuiz = () => {
    setSelectedQuiz(null);
    setQuizStarted(false);
    setQuizResult(null);
    setQuestions([]);
    setAnswers({});
    setCurrentQuestion(0);
  };

  const availableQuizzes = quizzes?.filter((q) => q.isPublished) || [];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl md:text-3xl font-bold" data-testid="text-quizzes-title">
          Quizzes
        </h1>
        <p className="text-muted-foreground mt-1">
          {isTeacher ? "View published quizzes" : "Test your knowledge with interactive quizzes"}
        </p>
      </div>

      {isLoading ? (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-48" />
          ))}
        </div>
      ) : availableQuizzes.length === 0 ? (
        <Card>
          <CardContent className="py-16 text-center">
            <BookOpen className="h-12 w-12 mx-auto mb-4 text-muted-foreground opacity-50" />
            <h3 className="text-lg font-semibold mb-2">No Quizzes Available</h3>
            <p className="text-muted-foreground">
              {isTeacher ? "Create quizzes in the Quiz Builder." : "Check back later for new quizzes."}
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {availableQuizzes.map((quiz) => {
            const attempt = getAttemptForQuiz(quiz.id);
            const hasCompleted = attempt?.completedAt;

            return (
              <Card key={quiz.id} data-testid={`card-quiz-${quiz.id}`}>
                <CardHeader>
                  <div className="flex items-start justify-between gap-2">
                    <Badge variant="secondary">{quiz.subject}</Badge>
                    {hasCompleted && (
                      <Badge variant="default" className="bg-green-600">
                        <Trophy className="h-3 w-3 mr-1" />
                        {attempt?.score}/{attempt?.maxScore}
                      </Badge>
                    )}
                  </div>
                  <CardTitle className="text-lg mt-2">{quiz.title}</CardTitle>
                  <CardDescription>{quiz.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                    <span className="flex items-center gap-1">
                      <BookOpen className="h-4 w-4" />
                      {quiz.grade}
                    </span>
                    {quiz.timeLimit && (
                      <span className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        {quiz.timeLimit} min
                      </span>
                    )}
                  </div>
                  {!isTeacher && (
                    <Button
                      className="w-full"
                      onClick={() => handleStartQuiz(quiz)}
                      disabled={!!hasCompleted}
                      data-testid={`button-start-quiz-${quiz.id}`}
                    >
                      {hasCompleted ? (
                        <>
                          <CheckCircle2 className="h-4 w-4 mr-2" />
                          Completed
                        </>
                      ) : (
                        <>
                          <Play className="h-4 w-4 mr-2" />
                          Start Quiz
                        </>
                      )}
                    </Button>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      <Dialog open={!!selectedQuiz && quizStarted} onOpenChange={(open) => !open && handleCloseQuiz()}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{selectedQuiz?.title}</DialogTitle>
          </DialogHeader>

          {quizResult ? (
            <div className="py-8 text-center">
              <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Trophy className="h-10 w-10 text-primary" />
              </div>
              <h3 className="text-2xl font-bold mb-2" data-testid="text-quiz-score">
                {quizResult.score} / {quizResult.maxScore}
              </h3>
              <p className="text-muted-foreground mb-6">
                You scored {Math.round((quizResult.score / quizResult.maxScore) * 100)}%
              </p>
              <Progress value={(quizResult.score / quizResult.maxScore) * 100} className="w-48 mx-auto mb-6" />
              <Button onClick={handleCloseQuiz} data-testid="button-close-quiz">
                Close
              </Button>
            </div>
          ) : startQuizMutation.isPending ? (
            <div className="py-16 text-center">
              <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
              <p className="text-muted-foreground">Loading quiz...</p>
            </div>
          ) : questions.length > 0 ? (
            <div className="space-y-6">
              <div className="flex items-center justify-between gap-4">
                <span className="text-sm text-muted-foreground">
                  Question {currentQuestion + 1} of {questions.length}
                </span>
                <Progress value={((currentQuestion + 1) / questions.length) * 100} className="w-32" />
              </div>

              <div className="bg-muted/50 rounded-lg p-6">
                <h3 className="text-lg font-medium mb-4" data-testid="text-question">
                  {questions[currentQuestion]?.questionText}
                </h3>

                <RadioGroup
                  value={answers[questions[currentQuestion]?.id] || ""}
                  onValueChange={(value) => handleSelectAnswer(questions[currentQuestion]?.id, value)}
                >
                  {(questions[currentQuestion]?.options as string[] || []).map((option, index) => (
                    <div key={index} className="flex items-center space-x-3 p-3 rounded-lg hover:bg-muted transition-colors">
                      <RadioGroupItem value={option} id={`option-${index}`} data-testid={`option-${index}`} />
                      <Label htmlFor={`option-${index}`} className="flex-1 cursor-pointer">
                        {option}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>

              <div className="flex justify-between gap-4">
                <Button
                  variant="outline"
                  onClick={() => setCurrentQuestion((prev) => Math.max(0, prev - 1))}
                  disabled={currentQuestion === 0}
                >
                  Previous
                </Button>

                {currentQuestion === questions.length - 1 ? (
                  <Button
                    onClick={handleSubmitQuiz}
                    disabled={Object.keys(answers).length !== questions.length || submitQuizMutation.isPending}
                    data-testid="button-submit-quiz"
                  >
                    {submitQuizMutation.isPending ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Submitting...
                      </>
                    ) : (
                      "Submit Quiz"
                    )}
                  </Button>
                ) : (
                  <Button
                    onClick={handleNextQuestion}
                    disabled={!answers[questions[currentQuestion]?.id]}
                    data-testid="button-next-question"
                  >
                    Next
                    <ArrowRight className="h-4 w-4 ml-2" />
                  </Button>
                )}
              </div>
            </div>
          ) : null}
        </DialogContent>
      </Dialog>
    </div>
  );
}
