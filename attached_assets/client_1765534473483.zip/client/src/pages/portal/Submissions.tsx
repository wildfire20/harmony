import { useQuery, useMutation } from "@tanstack/react-query";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Upload, Download, CheckCircle2, Clock, Eye, Loader2 } from "lucide-react";
import type { Submission, Assignment } from "@shared/schema";

type SubmissionWithDetails = Submission & {
  assignment?: Assignment;
  student?: { firstName: string | null; lastName: string | null; studentNumber: string | null };
};

export default function Submissions() {
  const { toast } = useToast();
  const [selectedSubmission, setSelectedSubmission] = useState<SubmissionWithDetails | null>(null);
  const [grade, setGrade] = useState("");
  const [feedback, setFeedback] = useState("");
  const [filterAssignment, setFilterAssignment] = useState<string>("all");

  const { data: submissions, isLoading } = useQuery<SubmissionWithDetails[]>({
    queryKey: ["/api/submissions/all"],
  });

  const { data: assignments } = useQuery<Assignment[]>({
    queryKey: ["/api/assignments"],
  });

  const gradeMutation = useMutation({
    mutationFn: async ({ id, grade, feedback }: { id: string; grade: number; feedback: string }) => {
      return apiRequest("PATCH", `/api/submissions/${id}/grade`, { grade, feedback });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/submissions/all"] });
      toast({ title: "Graded!", description: "Submission has been graded successfully." });
      setSelectedSubmission(null);
      setGrade("");
      setFeedback("");
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to grade submission.", variant: "destructive" });
    },
  });

  const filteredSubmissions = submissions?.filter((s) => {
    if (filterAssignment === "all") return true;
    return s.assignmentId === filterAssignment;
  }) || [];

  const ungradedCount = submissions?.filter((s) => s.grade === null || s.grade === undefined).length || 0;
  const gradedCount = submissions?.filter((s) => s.grade !== null && s.grade !== undefined).length || 0;

  const formatDate = (date: Date | string | null) => {
    if (!date) return "N/A";
    return new Date(date).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const handleGradeSubmit = () => {
    if (!selectedSubmission || !grade) return;
    gradeMutation.mutate({
      id: selectedSubmission.id,
      grade: parseInt(grade),
      feedback,
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl md:text-3xl font-bold" data-testid="text-submissions-title">
          Student Submissions
        </h1>
        <p className="text-muted-foreground mt-1">
          Review and grade student work
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
            <CardTitle className="text-sm font-medium">Total Submissions</CardTitle>
            <Upload className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{submissions?.length || 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
            <CardTitle className="text-sm font-medium">Pending Review</CardTitle>
            <Clock className="h-4 w-4 text-amber-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{ungradedCount}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
            <CardTitle className="text-sm font-medium">Graded</CardTitle>
            <CheckCircle2 className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{gradedCount}</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <CardTitle>Submissions</CardTitle>
              <CardDescription>Filter and review student work</CardDescription>
            </div>
            <Select value={filterAssignment} onValueChange={setFilterAssignment}>
              <SelectTrigger className="w-[200px]" data-testid="select-filter-assignment">
                <SelectValue placeholder="Filter by assignment" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Assignments</SelectItem>
                {assignments?.map((a) => (
                  <SelectItem key={a.id} value={a.id}>{a.title}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : filteredSubmissions.length === 0 ? (
            <div className="py-12 text-center">
              <Upload className="h-10 w-10 mx-auto mb-3 text-muted-foreground opacity-50" />
              <h3 className="font-semibold mb-1">No Submissions</h3>
              <p className="text-sm text-muted-foreground">
                Student submissions will appear here.
              </p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Student</TableHead>
                  <TableHead>Assignment</TableHead>
                  <TableHead>Submitted</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredSubmissions.map((submission) => (
                  <TableRow key={submission.id} data-testid={`row-submission-${submission.id}`}>
                    <TableCell className="font-medium">
                      {submission.student?.firstName} {submission.student?.lastName}
                      <span className="block text-xs text-muted-foreground">
                        {submission.student?.studentNumber}
                      </span>
                    </TableCell>
                    <TableCell>{submission.assignment?.title || "Assignment"}</TableCell>
                    <TableCell>{formatDate(submission.submittedAt)}</TableCell>
                    <TableCell>
                      {submission.grade !== null && submission.grade !== undefined ? (
                        <Badge className="bg-green-600">
                          {submission.grade}/{submission.assignment?.maxPoints || 100}
                        </Badge>
                      ) : (
                        <Badge variant="secondary">Pending</Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Button variant="ghost" size="sm" asChild>
                          <a href={submission.fileUrl} target="_blank" rel="noopener noreferrer">
                            <Download className="h-4 w-4 mr-1" />
                            Download
                          </a>
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setSelectedSubmission(submission);
                            setGrade(submission.grade?.toString() || "");
                            setFeedback(submission.feedback || "");
                          }}
                          data-testid={`button-grade-${submission.id}`}
                        >
                          <Eye className="h-4 w-4 mr-1" />
                          {submission.grade !== null ? "Edit" : "Grade"}
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={!!selectedSubmission} onOpenChange={(open) => !open && setSelectedSubmission(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Grade Submission</DialogTitle>
          </DialogHeader>
          {selectedSubmission && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-muted-foreground">Student:</span>
                  <p className="font-medium">
                    {selectedSubmission.student?.firstName} {selectedSubmission.student?.lastName}
                  </p>
                </div>
                <div>
                  <span className="text-muted-foreground">Assignment:</span>
                  <p className="font-medium">{selectedSubmission.assignment?.title}</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Submitted:</span>
                  <p className="font-medium">{formatDate(selectedSubmission.submittedAt)}</p>
                </div>
                <div>
                  <span className="text-muted-foreground">File:</span>
                  <Button variant="link" size="sm" className="p-0 h-auto" asChild>
                    <a href={selectedSubmission.fileUrl} target="_blank" rel="noopener noreferrer">
                      <Download className="h-3 w-3 mr-1" />
                      {selectedSubmission.fileName}
                    </a>
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Grade (out of {selectedSubmission.assignment?.maxPoints || 100})</label>
                <Input
                  type="number"
                  value={grade}
                  onChange={(e) => setGrade(e.target.value)}
                  min="0"
                  max={selectedSubmission.assignment?.maxPoints || 100}
                  data-testid="input-grade"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Feedback (Optional)</label>
                <Textarea
                  value={feedback}
                  onChange={(e) => setFeedback(e.target.value)}
                  placeholder="Provide feedback for the student..."
                  className="min-h-[80px]"
                  data-testid="textarea-feedback"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <Button variant="outline" className="flex-1" onClick={() => setSelectedSubmission(null)}>
                  Cancel
                </Button>
                <Button
                  className="flex-1"
                  onClick={handleGradeSubmit}
                  disabled={!grade || gradeMutation.isPending}
                  data-testid="button-submit-grade"
                >
                  {gradeMutation.isPending ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="h-4 w-4 mr-2" />
                      Save Grade
                    </>
                  )}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
