import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, BookOpen, Users, Calendar } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { Subject, ClassGroup, TimetableEntry, User } from "@shared/schema";

const GRADES = ["Pre-K", "Kindergarten", "Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5", "Grade 6"];
const DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

export default function ClassManagement() {
  const { toast } = useToast();
  const [isSubjectOpen, setIsSubjectOpen] = useState(false);
  const [isClassOpen, setIsClassOpen] = useState(false);
  const [isTimetableOpen, setIsTimetableOpen] = useState(false);

  const [subjectForm, setSubjectForm] = useState({ name: "", code: "", description: "", grade: "" });
  const [classForm, setClassForm] = useState({ name: "", grade: "", teacherId: "", roomNumber: "" });
  const [timetableForm, setTimetableForm] = useState({
    subjectId: "",
    classGroupId: "",
    teacherId: "",
    dayOfWeek: 1,
    startTime: "08:00",
    endTime: "09:00",
    roomNumber: "",
  });

  const { data: subjects = [] } = useQuery<Subject[]>({
    queryKey: ["/api/subjects"],
  });

  const { data: classGroups = [] } = useQuery<ClassGroup[]>({
    queryKey: ["/api/class-groups"],
  });

  const { data: timetable = [] } = useQuery<(TimetableEntry & { subjectName?: string; className?: string; teacherName?: string })[]>({
    queryKey: ["/api/timetable"],
  });

  const { data: teachers = [] } = useQuery<User[]>({
    queryKey: ["/api/users"],
    select: (data) => data.filter(u => u.role === "teacher"),
  });

  const createSubjectMutation = useMutation({
    mutationFn: async (data: typeof subjectForm) => {
      return apiRequest("/api/subjects", {
        method: "POST",
        body: JSON.stringify(data),
        headers: { "Content-Type": "application/json" },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/subjects"] });
      setIsSubjectOpen(false);
      setSubjectForm({ name: "", code: "", description: "", grade: "" });
      toast({ title: "Subject created successfully" });
    },
  });

  const createClassMutation = useMutation({
    mutationFn: async (data: typeof classForm) => {
      return apiRequest("/api/class-groups", {
        method: "POST",
        body: JSON.stringify(data),
        headers: { "Content-Type": "application/json" },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/class-groups"] });
      setIsClassOpen(false);
      setClassForm({ name: "", grade: "", teacherId: "", roomNumber: "" });
      toast({ title: "Class group created successfully" });
    },
  });

  const createTimetableMutation = useMutation({
    mutationFn: async (data: typeof timetableForm) => {
      return apiRequest("/api/timetable", {
        method: "POST",
        body: JSON.stringify(data),
        headers: { "Content-Type": "application/json" },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/timetable"] });
      setIsTimetableOpen(false);
      setTimetableForm({
        subjectId: "",
        classGroupId: "",
        teacherId: "",
        dayOfWeek: 1,
        startTime: "08:00",
        endTime: "09:00",
        roomNumber: "",
      });
      toast({ title: "Timetable entry created successfully" });
    },
  });

  const deleteSubjectMutation = useMutation({
    mutationFn: (id: string) => apiRequest(`/api/subjects/${id}`, { method: "DELETE" }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/subjects"] });
      toast({ title: "Subject deleted" });
    },
  });

  const deleteClassMutation = useMutation({
    mutationFn: (id: string) => apiRequest(`/api/class-groups/${id}`, { method: "DELETE" }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/class-groups"] });
      toast({ title: "Class group deleted" });
    },
  });

  const deleteTimetableMutation = useMutation({
    mutationFn: (id: string) => apiRequest(`/api/timetable/${id}`, { method: "DELETE" }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/timetable"] });
      toast({ title: "Timetable entry deleted" });
    },
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold" data-testid="text-class-management-title">Class & Subject Management</h1>
        <p className="text-muted-foreground">Manage subjects, class groups, and timetables</p>
      </div>

      <Tabs defaultValue="subjects">
        <TabsList>
          <TabsTrigger value="subjects" data-testid="tab-subjects">
            <BookOpen className="w-4 h-4 mr-2" />
            Subjects
          </TabsTrigger>
          <TabsTrigger value="classes" data-testid="tab-classes">
            <Users className="w-4 h-4 mr-2" />
            Class Groups
          </TabsTrigger>
          <TabsTrigger value="timetable" data-testid="tab-timetable">
            <Calendar className="w-4 h-4 mr-2" />
            Timetable
          </TabsTrigger>
        </TabsList>

        <TabsContent value="subjects" className="mt-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-4">
              <CardTitle>Subjects</CardTitle>
              <Dialog open={isSubjectOpen} onOpenChange={setIsSubjectOpen}>
                <DialogTrigger asChild>
                  <Button data-testid="button-add-subject">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Subject
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add New Subject</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={(e) => { e.preventDefault(); createSubjectMutation.mutate(subjectForm); }} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Subject Name</Label>
                        <Input
                          value={subjectForm.name}
                          onChange={(e) => setSubjectForm({ ...subjectForm, name: e.target.value })}
                          placeholder="e.g., Mathematics"
                          required
                          data-testid="input-subject-name"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Subject Code</Label>
                        <Input
                          value={subjectForm.code}
                          onChange={(e) => setSubjectForm({ ...subjectForm, code: e.target.value })}
                          placeholder="e.g., MATH101"
                          data-testid="input-subject-code"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label>Grade</Label>
                      <Select value={subjectForm.grade} onValueChange={(v) => setSubjectForm({ ...subjectForm, grade: v })}>
                        <SelectTrigger data-testid="select-subject-grade">
                          <SelectValue placeholder="Select grade" />
                        </SelectTrigger>
                        <SelectContent>
                          {GRADES.map(g => (
                            <SelectItem key={g} value={g}>{g}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Description</Label>
                      <Textarea
                        value={subjectForm.description}
                        onChange={(e) => setSubjectForm({ ...subjectForm, description: e.target.value })}
                        placeholder="Optional description..."
                        data-testid="input-subject-description"
                      />
                    </div>
                    <Button type="submit" className="w-full" disabled={createSubjectMutation.isPending} data-testid="button-submit-subject">
                      {createSubjectMutation.isPending ? "Creating..." : "Create Subject"}
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              {subjects.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">No subjects created yet.</div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Code</TableHead>
                      <TableHead>Grade</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {subjects.map((subject) => (
                      <TableRow key={subject.id} data-testid={`row-subject-${subject.id}`}>
                        <TableCell className="font-medium">{subject.name}</TableCell>
                        <TableCell><Badge variant="outline">{subject.code || "-"}</Badge></TableCell>
                        <TableCell>{subject.grade}</TableCell>
                        <TableCell className="max-w-xs truncate">{subject.description || "-"}</TableCell>
                        <TableCell>
                          <Button variant="ghost" size="icon" onClick={() => deleteSubjectMutation.mutate(subject.id)} data-testid={`button-delete-subject-${subject.id}`}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="classes" className="mt-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-4">
              <CardTitle>Class Groups</CardTitle>
              <Dialog open={isClassOpen} onOpenChange={setIsClassOpen}>
                <DialogTrigger asChild>
                  <Button data-testid="button-add-class">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Class
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add New Class Group</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={(e) => { e.preventDefault(); createClassMutation.mutate(classForm); }} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Class Name</Label>
                        <Input
                          value={classForm.name}
                          onChange={(e) => setClassForm({ ...classForm, name: e.target.value })}
                          placeholder="e.g., Grade 1A"
                          required
                          data-testid="input-class-name"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Room Number</Label>
                        <Input
                          value={classForm.roomNumber}
                          onChange={(e) => setClassForm({ ...classForm, roomNumber: e.target.value })}
                          placeholder="e.g., Room 101"
                          data-testid="input-room-number"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label>Grade</Label>
                      <Select value={classForm.grade} onValueChange={(v) => setClassForm({ ...classForm, grade: v })}>
                        <SelectTrigger data-testid="select-class-grade">
                          <SelectValue placeholder="Select grade" />
                        </SelectTrigger>
                        <SelectContent>
                          {GRADES.map(g => (
                            <SelectItem key={g} value={g}>{g}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Class Teacher (Optional)</Label>
                      <Select value={classForm.teacherId} onValueChange={(v) => setClassForm({ ...classForm, teacherId: v })}>
                        <SelectTrigger data-testid="select-class-teacher">
                          <SelectValue placeholder="Select teacher" />
                        </SelectTrigger>
                        <SelectContent>
                          {teachers.map(t => (
                            <SelectItem key={t.id} value={t.id}>{t.firstName} {t.lastName}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <Button type="submit" className="w-full" disabled={createClassMutation.isPending} data-testid="button-submit-class">
                      {createClassMutation.isPending ? "Creating..." : "Create Class"}
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              {classGroups.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">No class groups created yet.</div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Grade</TableHead>
                      <TableHead>Room</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {classGroups.map((cg) => (
                      <TableRow key={cg.id} data-testid={`row-class-${cg.id}`}>
                        <TableCell className="font-medium">{cg.name}</TableCell>
                        <TableCell><Badge variant="outline">{cg.grade}</Badge></TableCell>
                        <TableCell>{cg.roomNumber || "-"}</TableCell>
                        <TableCell>
                          <Button variant="ghost" size="icon" onClick={() => deleteClassMutation.mutate(cg.id)} data-testid={`button-delete-class-${cg.id}`}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="timetable" className="mt-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-4">
              <CardTitle>Timetable</CardTitle>
              <Dialog open={isTimetableOpen} onOpenChange={setIsTimetableOpen}>
                <DialogTrigger asChild>
                  <Button data-testid="button-add-timetable">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Entry
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add Timetable Entry</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={(e) => { e.preventDefault(); createTimetableMutation.mutate(timetableForm); }} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Subject</Label>
                        <Select value={timetableForm.subjectId} onValueChange={(v) => setTimetableForm({ ...timetableForm, subjectId: v })}>
                          <SelectTrigger data-testid="select-timetable-subject">
                            <SelectValue placeholder="Select subject" />
                          </SelectTrigger>
                          <SelectContent>
                            {subjects.map(s => (
                              <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Class</Label>
                        <Select value={timetableForm.classGroupId} onValueChange={(v) => setTimetableForm({ ...timetableForm, classGroupId: v })}>
                          <SelectTrigger data-testid="select-timetable-class">
                            <SelectValue placeholder="Select class" />
                          </SelectTrigger>
                          <SelectContent>
                            {classGroups.map(c => (
                              <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label>Teacher</Label>
                      <Select value={timetableForm.teacherId} onValueChange={(v) => setTimetableForm({ ...timetableForm, teacherId: v })}>
                        <SelectTrigger data-testid="select-timetable-teacher">
                          <SelectValue placeholder="Select teacher" />
                        </SelectTrigger>
                        <SelectContent>
                          {teachers.map(t => (
                            <SelectItem key={t.id} value={t.id}>{t.firstName} {t.lastName}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label>Day</Label>
                        <Select value={String(timetableForm.dayOfWeek)} onValueChange={(v) => setTimetableForm({ ...timetableForm, dayOfWeek: parseInt(v) })}>
                          <SelectTrigger data-testid="select-timetable-day">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {DAYS.map((d, i) => (
                              <SelectItem key={i} value={String(i)}>{d}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Start Time</Label>
                        <Input
                          type="time"
                          value={timetableForm.startTime}
                          onChange={(e) => setTimetableForm({ ...timetableForm, startTime: e.target.value })}
                          data-testid="input-start-time"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>End Time</Label>
                        <Input
                          type="time"
                          value={timetableForm.endTime}
                          onChange={(e) => setTimetableForm({ ...timetableForm, endTime: e.target.value })}
                          data-testid="input-end-time"
                        />
                      </div>
                    </div>
                    <Button type="submit" className="w-full" disabled={createTimetableMutation.isPending} data-testid="button-submit-timetable">
                      {createTimetableMutation.isPending ? "Creating..." : "Add Entry"}
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              {timetable.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">No timetable entries yet.</div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Day</TableHead>
                      <TableHead>Time</TableHead>
                      <TableHead>Subject</TableHead>
                      <TableHead>Class</TableHead>
                      <TableHead>Teacher</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {timetable.map((entry) => (
                      <TableRow key={entry.id} data-testid={`row-timetable-${entry.id}`}>
                        <TableCell>{DAYS[entry.dayOfWeek]}</TableCell>
                        <TableCell>{entry.startTime} - {entry.endTime}</TableCell>
                        <TableCell>{entry.subjectName || "-"}</TableCell>
                        <TableCell>{entry.className || "-"}</TableCell>
                        <TableCell>{entry.teacherName || "-"}</TableCell>
                        <TableCell>
                          <Button variant="ghost" size="icon" onClick={() => deleteTimetableMutation.mutate(entry.id)} data-testid={`button-delete-timetable-${entry.id}`}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
