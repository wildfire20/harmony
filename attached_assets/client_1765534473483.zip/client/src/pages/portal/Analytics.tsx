import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Users,
  GraduationCap,
  BookOpen,
  ClipboardList,
  CheckCircle,
  Clock,
  TrendingUp,
  BarChart3,
} from "lucide-react";

interface AnalyticsData {
  studentCount: number;
  teacherCount: number;
  pendingEnrollments: number;
  approvedEnrollments: number;
  totalSubmissions: number;
  gradedSubmissions: number;
  submissionRate: number;
  gradeDistribution: Record<string, number>;
}

export default function Analytics() {
  const { data: analytics, isLoading } = useQuery<AnalyticsData>({
    queryKey: ["/api/analytics"],
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-muted-foreground">Loading analytics...</div>
      </div>
    );
  }

  if (!analytics) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        Unable to load analytics data.
      </div>
    );
  }

  const gradeDistributionEntries = Object.entries(analytics.gradeDistribution || {});

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold" data-testid="text-analytics-title">School Analytics</h1>
        <p className="text-muted-foreground">Overview of student activity and school performance</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card data-testid="card-student-count">
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Students</CardTitle>
            <GraduationCap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analytics.studentCount}</div>
            <p className="text-xs text-muted-foreground">Registered students</p>
          </CardContent>
        </Card>

        <Card data-testid="card-teacher-count">
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Teachers</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analytics.teacherCount}</div>
            <p className="text-xs text-muted-foreground">Active teachers</p>
          </CardContent>
        </Card>

        <Card data-testid="card-pending-enrollments">
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Enrollments</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analytics.pendingEnrollments}</div>
            <p className="text-xs text-muted-foreground">Awaiting approval</p>
          </CardContent>
        </Card>

        <Card data-testid="card-approved-enrollments">
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Approved Enrollments</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analytics.approvedEnrollments}</div>
            <p className="text-xs text-muted-foreground">This period</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card data-testid="card-submissions">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ClipboardList className="h-5 w-5" />
              Submission Statistics
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Total Submissions</span>
              <span className="font-bold text-lg">{analytics.totalSubmissions}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Graded Submissions</span>
              <span className="font-bold text-lg">{analytics.gradedSubmissions}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Grading Progress</span>
              <Badge variant={analytics.submissionRate >= 80 ? "default" : analytics.submissionRate >= 50 ? "secondary" : "destructive"}>
                {analytics.submissionRate}%
              </Badge>
            </div>

            <div className="pt-4">
              <div className="h-3 bg-muted rounded-full overflow-hidden">
                <div
                  className="h-full bg-primary transition-all duration-500"
                  style={{ width: `${analytics.submissionRate}%` }}
                />
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                {analytics.gradedSubmissions} of {analytics.totalSubmissions} submissions graded
              </p>
            </div>
          </CardContent>
        </Card>

        <Card data-testid="card-grade-distribution">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              Student Distribution by Grade
            </CardTitle>
          </CardHeader>
          <CardContent>
            {gradeDistributionEntries.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No student grade data available
              </div>
            ) : (
              <div className="space-y-3">
                {gradeDistributionEntries
                  .sort(([a], [b]) => a.localeCompare(b))
                  .map(([grade, count]) => {
                    const maxCount = Math.max(...Object.values(analytics.gradeDistribution));
                    const percentage = (count / maxCount) * 100;
                    return (
                      <div key={grade} className="space-y-1">
                        <div className="flex items-center justify-between text-sm">
                          <span>{grade}</span>
                          <span className="font-medium">{count} students</span>
                        </div>
                        <div className="h-2 bg-muted rounded-full overflow-hidden">
                          <div
                            className="h-full bg-primary/70 transition-all duration-500"
                            style={{ width: `${percentage}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Quick Insights
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <div className="p-4 bg-muted/50 rounded-lg">
              <div className="text-sm text-muted-foreground mb-1">Student-Teacher Ratio</div>
              <div className="text-2xl font-bold">
                {analytics.teacherCount > 0
                  ? `${Math.round(analytics.studentCount / analytics.teacherCount)}:1`
                  : "N/A"}
              </div>
            </div>
            <div className="p-4 bg-muted/50 rounded-lg">
              <div className="text-sm text-muted-foreground mb-1">Enrollment Approval Rate</div>
              <div className="text-2xl font-bold">
                {analytics.pendingEnrollments + analytics.approvedEnrollments > 0
                  ? `${Math.round(
                      (analytics.approvedEnrollments /
                        (analytics.pendingEnrollments + analytics.approvedEnrollments)) *
                        100
                    )}%`
                  : "N/A"}
              </div>
            </div>
            <div className="p-4 bg-muted/50 rounded-lg">
              <div className="text-sm text-muted-foreground mb-1">Avg. Submissions per Student</div>
              <div className="text-2xl font-bold">
                {analytics.studentCount > 0
                  ? (analytics.totalSubmissions / analytics.studentCount).toFixed(1)
                  : "0"}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
