import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { SidebarProvider, SidebarTrigger, SidebarInset } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/portal/AppSidebar";
import { ThemeToggle } from "@/components/theme-toggle";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch, Route } from "wouter";
import Dashboard from "@/pages/portal/Dashboard";
import Announcements from "@/pages/portal/Announcements";
import Assignments from "@/pages/portal/Assignments";
import Quizzes from "@/pages/portal/Quizzes";
import QuizBuilder from "@/pages/portal/QuizBuilder";
import Submissions from "@/pages/portal/Submissions";
import Enrollments from "@/pages/portal/Enrollments";
import Gradebook from "@/pages/portal/Gradebook";
import Resources from "@/pages/portal/Resources";
import Analytics from "@/pages/portal/Analytics";
import BulkImport from "@/pages/portal/BulkImport";
import ClassManagement from "@/pages/portal/ClassManagement";
import Attendance from "@/pages/portal/Attendance";
import Calendar from "@/pages/portal/Calendar";
import StudentManagement from "@/pages/portal/StudentManagement";
import TeacherManagement from "@/pages/portal/TeacherManagement";
import NotFound from "@/pages/not-found";

export default function Home() {
  const { user, isLoading, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      setLocation("/");
    }
  }, [isLoading, isAuthenticated, setLocation]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="space-y-4 w-full max-w-md px-4">
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-8 w-3/4" />
          <Skeleton className="h-64 w-full" />
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  const userRole = user?.role || "student";

  const sidebarStyle = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  return (
    <SidebarProvider style={sidebarStyle as React.CSSProperties}>
      <div className="flex min-h-screen w-full">
        <AppSidebar userRole={userRole as "student" | "teacher" | "admin"} />
        <SidebarInset className="flex flex-col flex-1">
          <header className="flex items-center justify-between gap-4 p-4 border-b sticky top-0 z-40 bg-background">
            <SidebarTrigger data-testid="button-sidebar-toggle" />
            <ThemeToggle />
          </header>
          <main className="flex-1 overflow-auto p-4 md:p-6">
            <Switch>
              <Route path="/portal" component={Dashboard} />
              <Route path="/portal/announcements" component={Announcements} />
              <Route path="/portal/assignments" component={Assignments} />
              <Route path="/portal/quizzes" component={Quizzes} />
              <Route path="/portal/quiz-builder" component={QuizBuilder} />
              <Route path="/portal/submissions" component={Submissions} />
              <Route path="/portal/enrollments" component={Enrollments} />
              <Route path="/portal/gradebook" component={Gradebook} />
              <Route path="/portal/resources" component={Resources} />
              <Route path="/portal/analytics" component={Analytics} />
              <Route path="/portal/bulk-import" component={BulkImport} />
              <Route path="/portal/class-management" component={ClassManagement} />
              <Route path="/portal/attendance" component={Attendance} />
              <Route path="/portal/calendar" component={Calendar} />
              <Route path="/portal/students" component={StudentManagement} />
              <Route path="/portal/teachers" component={TeacherManagement} />
              <Route component={Dashboard} />
            </Switch>
          </main>
        </SidebarInset>
      </div>
    </SidebarProvider>
  );
}
